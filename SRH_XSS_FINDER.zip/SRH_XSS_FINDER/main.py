#!/usr/bin/env python3
"""Convenience entry: python main.py <url> [options]"""
import sys

from xsscan.cli import main

if __name__ == "__main__":
    sys.exit(main())
