#!/usr/bin/env python3
"""xsscan console -- local web UI for the xsscan pipeline.

Wraps Crawler -> Scanner -> Analyzer -> Reporter, exposes it as a REST +
SSE API, and serves the dashboard in static/.

Every discovered endpoint and every candidate finding is pushed live over
Server-Sent Events as soon as the engine produces it. Candidates are then
handed to a headless-browser Verifier (see xsscan/verifier.py): a finding
is only ever labeled "confirmed" once a real JavaScript dialog fires
during an actual page load -- never just because the payload showed up
in a response. After the reflected scan, discovered forms are also
tested for stored XSS (submit -> revisit -> verify) via
xsscan/stored.py, using the same confirm-by-execution standard.

Pause/resume/stop are wired straight to the pause_event/stop_event the
engine already supports in Crawler and Scanner.

Run with:  python server.py
Then open: http://127.0.0.1:8765
"""
from __future__ import annotations

import json
import logging
import os
import queue
import threading
import time
import uuid
import webbrowser
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import parse_qsl

import requests
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from xsscan.analyzer import Analyzer, AnalyzerConfig
from xsscan.crawler import Crawler
from xsscan.domxss import DomFinding, DomXSSTester
from xsscan.reporter import ScanReport, finding_to_dict
from xsscan.scanner import ScanResult, Scanner
from xsscan.stored import StoredFinding, StoredXSSTester
from xsscan.verifier import Verifier

log = logging.getLogger("xsscan.server")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)

APP_DIR = Path(__file__).resolve().parent
STATIC_DIR = APP_DIR / "static"
REPORTS_DIR = APP_DIR / "reports"
REPORTS_DIR.mkdir(exist_ok=True)

app = FastAPI(title="xsscan console")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

RUNNING_PHASES = ("queued", "crawling", "scanning", "verifying", "stored_testing", "dom_testing")


# ---------------------------------------------------------------------- #
# Shared headless-browser verifier
# ---------------------------------------------------------------------- #
# One Chromium instance for the whole server (launching it per-job would be
# far too slow). All Playwright calls happen on this one dedicated worker
# thread; scan threads submit verification work through a queue instead of
# touching Playwright directly (its sync API is not thread-safe).
VERIFIER = Verifier(pool_size=int(os.environ.get("XSSCAN_BROWSER_WORKERS", "3")))
_verify_queue: "queue.Queue[Optional[Callable]]" = queue.Queue()


def _verifier_worker() -> None:
    ok = VERIFIER.start()
    if not ok:
        log.warning(
            "Execution verification is DISABLED. Findings will be labeled "
            "'unverified' (heuristic only) instead of confirmed/rejected. "
            "To enable it: pip install playwright && playwright install chromium"
        )
    while True:
        task = _verify_queue.get()
        if task is None:
            break
        try:
            task()
        except Exception:
            log.exception("verification task failed")
        finally:
            _verify_queue.task_done()


threading.Thread(target=_verifier_worker, daemon=True).start()


# ---------------------------------------------------------------------- #
# Request / job model
# ---------------------------------------------------------------------- #
class ScanConfig(BaseModel):
    url: str
    authorized: bool = False
    scope: str = "host"                 # host | prefix | all
    depth: int = 3
    pages: int = 100
    delay: float = 0.1
    concurrency: int = 4
    timeout: float = 10.0
    retries: int = 1
    cookies: str = ""                   # "name=value; name2=value2"
    headers: str = ""                   # "Name: value\nName2: value2"
    user_agent: str = "xsscan/0.1 (authorized test)"
    verify_ssl: bool = True
    no_encoded: bool = False
    min_confidence: float = 0.0
    test_stored: bool = True            # run the stored-XSS phase after the reflected scan
    test_dom_xss: bool = True           # run the DOM-XSS phase (no server writes; safe default-on)


PHASE_ORDER = ["crawling", "scanning", "verifying", "stored_testing", "dom_testing"]
# Relative share of total scan time each phase typically takes -- used only
# to turn "which phase are we in + how far through it" into a single overall
# percentage. Approximate by design (crawl/verify/stored/DOM durations vary
# a lot by target); good enough for a progress bar and a rough ETA, not a
# guarantee.
PHASE_WEIGHT = {"crawling": 5, "scanning": 45, "verifying": 15,
                "stored_testing": 20, "dom_testing": 15}


def _active_phases(cfg: "ScanConfig") -> list[str]:
    """Which pipeline phases this job's config will actually run, in order.
    Skipped phases (no headless browser, stored/DOM testing turned off)
    drop out so their weight isn't wasted on something that never happens."""
    phases = ["crawling", "scanning"]
    if VERIFIER.available:
        phases.append("verifying")
    if cfg.test_stored:
        phases.append("stored_testing")
    if cfg.test_dom_xss and VERIFIER.available:
        phases.append("dom_testing")
    return phases


class ScanJob:
    """One scan run: its live state, its event history for SSE, and the
    findings/endpoints it has produced so far (available immediately,
    not just after the scan finishes)."""

    def __init__(self, job_id: str, config: ScanConfig):
        self.id = job_id
        self.config = config
        self.phase = "queued"           # queued|crawling|scanning|verifying|stored_testing|done|error|stopped
        self.paused = False
        self.error: Optional[str] = None
        self.points_found = 0
        self.scan_done = 0
        self.scan_total = 0
        self.started_at = time.time()
        self.finished_at: Optional[float] = None
        self.report: Optional[ScanReport] = None

        self.findings: list[dict] = []       # live reflected findings (candidate + verified)
        self.stored_findings: list[dict] = []  # live stored-XSS results
        self.dom_findings: list[dict] = []     # live DOM-XSS results
        self.endpoints: list[dict] = []
        self._finding_counter = 0
        self._findings_by_id: dict[int, dict] = {}
        self.pending_verifications = 0

        # Progress accounting -- how far through each phase we are, so an
        # overall completion % (and a rough ETA) can be shown while a scan
        # is still running. max_phase_index only moves forward, even across
        # "stopped"/"error", so a % computed after a stop still reflects how
        # far the run actually got instead of resetting to 0.
        self.max_phase_index = -1
        self.verify_total = 0
        self.stored_total = 0
        self.stored_done = 0
        self.dom_total = 0
        self.dom_done = 0

        self.lock = threading.RLock()
        self.pause_event = threading.Event()
        self.pause_event.set()               # set = running
        self.stop_event = threading.Event()

        self._subscribers: list[queue.Queue] = []
        self._history: list[dict] = []
        self._pub_lock = threading.Lock()

    def set_phase(self, phase: str) -> None:
        """Set job.phase and, for real pipeline phases, advance
        max_phase_index (never backward) so progress% stays monotonic."""
        with self.lock:
            self.phase = phase
            if phase in PHASE_ORDER:
                idx = PHASE_ORDER.index(phase)
                if idx > self.max_phase_index:
                    self.max_phase_index = idx

    # -------------------------- pub/sub for SSE -------------------------- #
    def publish(self, event_type: str, data: dict) -> None:
        ev = {"type": event_type, "data": data}
        with self._pub_lock:
            self._history.append(ev)
            if len(self._history) > 3000:
                self._history = self._history[-3000:]
            subs = list(self._subscribers)
        for q in subs:
            try:
                q.put_nowait(ev)
            except queue.Full:
                pass

    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=3000)
        with self._pub_lock:
            self._subscribers.append(q)
            for ev in self._history:
                q.put(ev)
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        with self._pub_lock:
            if q in self._subscribers:
                self._subscribers.remove(q)

    # ------------------------------ status ------------------------------ #
    def to_dict(self) -> dict:
        with self.lock:
            confirmed = sum(1 for f in self.findings if f.get("verification") == "confirmed")
            confirmed += sum(1 for f in self.stored_findings if f.get("verified"))
            confirmed += sum(1 for f in self.dom_findings if f.get("verified"))
            pct = _progress_pct(self)
            d = {
                "id": self.id,
                "url": self.config.url,
                "phase": self.phase,
                "paused": self.paused,
                "error": self.error,
                "points_found": self.points_found,
                "scan_done": self.scan_done,
                "scan_total": self.scan_total,
                "findings_count": len(self.findings),
                "stored_findings_count": len(self.stored_findings),
                "dom_findings_count": len(self.dom_findings),
                "confirmed_count": confirmed,
                "pending_verifications": self.pending_verifications,
                "verifier_available": VERIFIER.available,
                "started_at": self.started_at,
                "finished_at": self.finished_at,
                "progress_pct": pct,
                "eta_seconds": _eta_seconds(self, pct),
            }
            if self.report is not None:
                d["stats"] = self.report.stats
                d["duration"] = self.report.duration
        return d


def _phase_fraction(job: "ScanJob", phase: str) -> float:
    """How far through the *current* phase a job is, 0..1. Only meaningful
    for the phase job.phase is actually sitting in right now -- phases
    already passed count as 1.0 and phases not yet reached count as 0.0
    regardless of what this returns for them."""
    if phase == "crawling":
        # The crawler makes one blocking discover() call with no
        # sub-progress hook, so there's no finer signal than "started".
        # Assume roughly midway through rather than 0%, so the bar isn't
        # stuck at the very start for however long the crawl takes.
        return 0.5
    if phase == "scanning":
        return (job.scan_done / job.scan_total) if job.scan_total else 0.0
    if phase == "verifying":
        if not job.verify_total:
            return 1.0
        done = job.verify_total - job.pending_verifications
        return max(0.0, min(1.0, done / job.verify_total))
    if phase == "stored_testing":
        return (job.stored_done / job.stored_total) if job.stored_total else 0.0
    if phase == "dom_testing":
        return (job.dom_done / job.dom_total) if job.dom_total else 0.0
    return 0.0


def _progress_pct(job: "ScanJob") -> int:
    """Overall completion % across the whole pipeline (crawl -> scan ->
    verify -> stored -> DOM), weighted by each phase's typical share of
    total scan time. Approximate, not a guarantee -- see PHASE_WEIGHT."""
    if job.phase == "done":
        return 100
    if job.phase == "queued":
        return 0
    phases = _active_phases(job.config)
    weights = {p: PHASE_WEIGHT[p] for p in phases}
    total_w = sum(weights.values()) or 1
    done_w = 0.0
    for p in phases:
        idx = PHASE_ORDER.index(p)
        if idx < job.max_phase_index:
            done_w += weights[p]                       # phase fully behind us
        elif idx == job.max_phase_index:
            if job.phase == p:
                done_w += weights[p] * _phase_fraction(job, p)
            else:
                done_w += weights[p]                    # between phases
        # idx > max_phase_index: not reached yet, contributes 0
    pct = done_w / total_w * 100
    if job.phase in ("stopped", "error"):
        return int(round(pct))
    return max(0, min(99, int(round(pct))))


def _eta_seconds(job: "ScanJob", pct: int) -> Optional[float]:
    """Rough 'time remaining' estimate: linearly extrapolate from elapsed
    time and current % complete. Only meaningful while a scan is running --
    None once it's finished, stopped, or hasn't produced any progress yet."""
    if job.phase in ("done", "stopped", "error", "queued"):
        return None
    if pct <= 0 or pct >= 100:
        return None
    elapsed = time.time() - job.started_at
    if elapsed <= 1:
        return None
    total_est = elapsed / (pct / 100.0)
    return max(0.0, total_est - elapsed)



JOBS: dict[str, ScanJob] = {}
JOBS_LOCK = threading.Lock()


# ---------------------------------------------------------------------- #
# Session construction (mirrors cli.build_session)
# ---------------------------------------------------------------------- #
def _build_session(cfg: ScanConfig) -> requests.Session:
    s = requests.Session()
    s.headers["User-Agent"] = cfg.user_agent
    for line in cfg.headers.splitlines():
        line = line.strip()
        if not line or ":" not in line:
            continue
        name, _, value = line.partition(":")
        s.headers[name.strip()] = value.strip()
    for part in cfg.cookies.split(";"):
        part = part.strip()
        if not part or "=" not in part:
            continue
        name, _, value = part.partition("=")
        s.cookies.set(name.strip(), value.strip())
    return s


def _endpoint_dict(point) -> dict:
    return {
        "url": point.url, "method": point.method,
        "params": list(point.param_names), "source": point.source,
    }


def _session_cookies_headers(session: requests.Session) -> tuple[dict, dict]:
    cookies = session.cookies.get_dict()
    headers = {k: v for k, v in session.headers.items() if k.lower() != "user-agent"}
    return cookies, headers


# ---------------------------------------------------------------------- #
# Reflected-finding verification
# ---------------------------------------------------------------------- #
# Only the canonical, unmodified ("raw") payload is worth spending a real
# browser navigation on -- an *encoded* variant reflecting is already a much
# weaker signal (the analyzer's own notes say so), and verifying every
# encoding variant of every payload would make scans dramatically slower
# for little extra evidence. Encoded-variant candidates are shown in the UI
# as heuristic-only, clearly separate from anything confirmed.
def _verification_candidate(finding_dict: dict) -> bool:
    return finding_dict["exploitable"] and finding_dict["variant"] == "raw"


def _queue_reflected_verification(job: ScanJob, d: dict, session: requests.Session,
                                  points: list, finding_obj) -> None:
    if not VERIFIER.available:
        d["verification"] = "unverified"
        d["verification_evidence"] = "no headless browser available"
        return
    d["verification"] = "pending"
    with job.lock:
        job.pending_verifications += 1
        job.verify_total += 1

    def task():
        try:
            cookies, headers = _session_cookies_headers(session)
            if d["method"] == "GET":
                url = d.get("response_url") or d["url"]
                vr = VERIFIER.verify_get(url, cookies, headers)
            else:
                point = next((p for p in points
                             if p.url == d["url"] and p.method == d["method"]), None)
                if point is None:
                    d["verification"] = "unverified"
                    d["verification_evidence"] = "could not rebuild the POST request"
                    _publish_verify_update(job, d)
                    return
                tmp = Scanner(session, None, timeout=10)
                wire_url, kwargs = tmp._build_request(point, d["param"], d["payload"], d["variant"])
                data = kwargs.get("data")
                if isinstance(data, str):
                    data = dict(parse_qsl(data))
                vr = VERIFIER.verify_post(wire_url, data or {}, cookies, headers)

            d["verification"] = "confirmed" if vr.verified else (
                "not_executed" if vr.checked else "unverified")
            d["verification_evidence"] = vr.evidence or vr.error
        except Exception as e:
            d["verification"] = "unverified"
            d["verification_evidence"] = f"verification error: {e}"
        finally:
            # Mirror the result onto the real Finding object too (not just the
            # UI-facing dict) so the exported JSON/HTML report -- built from
            # these Finding objects -- carries the same confirmed/not-confirmed
            # status the dashboard shows live, instead of silently reverting to
            # "reflected" heuristic-only in the archived file.
            finding_obj.confirmed = (d["verification"] == "confirmed")
            finding_obj.execution_evidence = d.get("verification_evidence", "")
            with job.lock:
                job.pending_verifications = max(0, job.pending_verifications - 1)
            _publish_verify_update(job, d)

    _verify_queue.put(task)


def _progress_snapshot(job: "ScanJob") -> dict:
    """Overall pipeline progress, safe to merge into any SSE event payload."""
    with job.lock:
        pct = _progress_pct(job)
        return {"overall_pct": pct, "eta_seconds": _eta_seconds(job, pct)}


def _publish_verify_update(job: ScanJob, d: dict) -> None:
    job.publish("verify_update", {
        "id": d["id"], "verification": d["verification"],
        "verification_evidence": d.get("verification_evidence", ""),
        **_progress_snapshot(job),
    })


# ---------------------------------------------------------------------- #
# Background job runner
# ---------------------------------------------------------------------- #
def _run_job(job: ScanJob) -> None:
    cfg = job.config
    try:
        session = _build_session(cfg)

        def on_point(point):
            ep = _endpoint_dict(point)
            with job.lock:
                job.points_found += 1
                job.endpoints.append(ep)
            job.publish("endpoint", ep)

        crawler = Crawler(
            session, scope=cfg.scope, max_depth=cfg.depth,
            max_pages=cfg.pages, delay=cfg.delay, timeout=cfg.timeout,
            verify_ssl=cfg.verify_ssl, on_point=on_point,
            pause_event=job.pause_event, stop_event=job.stop_event,
        )
        job.set_phase("crawling")
        job.publish("state", {"phase": "crawling", **_progress_snapshot(job)})
        points = crawler.discover(cfg.url)

        if job.stop_event.is_set():
            with job.lock:
                job.finished_at = time.time()
            job.set_phase("stopped")
            job.publish("state", {"phase": "stopped", **_progress_snapshot(job)})
            return

        if not points:
            result = ScanResult(target=cfg.url, started=job.started_at,
                                finished=time.time())
            report = ScanReport.from_result(result)
            with job.lock:
                job.report = report
                job.finished_at = time.time()
            job.set_phase("done")
            job.publish("state", {"phase": "done", "stats": report.stats, **_progress_snapshot(job)})
            return

        def on_progress(done: int, total: int) -> None:
            with job.lock:
                job.scan_done = done
                job.scan_total = total
            job.publish("progress", {
                "done": done, "total": total,
                "pct": done * 100 // max(total, 1),
                **_progress_snapshot(job),
            })

        def on_finding(finding) -> None:
            with job.lock:
                job._finding_counter += 1
                d = finding_to_dict(finding)
                d["id"] = job._finding_counter
                job.findings.append(d)
                job._findings_by_id[d["id"]] = d
            if _verification_candidate(d):
                _queue_reflected_verification(job, d, session, points, finding)
            else:
                d["verification"] = "not_tested"
                d["verification_evidence"] = (
                    "encoded-variant or low-confidence reflection -- not "
                    "worth a browser check; see notes for why it's scored this way")
            job.publish("finding", d)

        analyzer = Analyzer(AnalyzerConfig(
            report_encoded_only=True,
            consider_url_encoded=not cfg.no_encoded,
            min_confidence=cfg.min_confidence,
        ))
        scanner = Scanner(
            session, analyzer, concurrency=cfg.concurrency, delay=cfg.delay,
            timeout=cfg.timeout, retries=cfg.retries,
            verify_ssl=cfg.verify_ssl, on_progress=on_progress,
            on_finding=on_finding,
            pause_event=job.pause_event, stop_event=job.stop_event,
        )
        job.set_phase("scanning")
        job.publish("state", {"phase": "scanning", **_progress_snapshot(job)})
        result = scanner.scan(points)

        stopped_early = getattr(result, "stopped_early", False) or job.stop_event.is_set()

        # Let queued reflected verifications settle *before* the report is
        # built, so the exported JSON/HTML actually carries confirmed/
        # not-confirmed status instead of the pre-verification snapshot.
        if VERIFIER.available and not stopped_early:
            job.set_phase("verifying")
            job.publish("state", {"phase": "verifying", **_progress_snapshot(job)})
            _verify_queue.join()

        stored_results = []
        if cfg.test_stored and not stopped_early:
            job.set_phase("stored_testing")
            job.publish("state", {"phase": "stored_testing", **_progress_snapshot(job)})
            if not VERIFIER.available:
                job.publish("activity", {
                    "text": "no headless browser available -- stored-XSS candidates "
                            "will be located but execution cannot be verified "
                            "(run: playwright install chromium)"})

            def on_stored_event(msg: str) -> None:
                job.publish("activity", {"text": msg})

            form_points = [p for p in points if getattr(p, "source", "") == "form"]
            with job.lock:
                job.stored_total = sum(len(p.param_names) for p in form_points)

            def on_stored_progress() -> None:
                with job.lock:
                    job.stored_done += 1
                job.publish("progress_update", _progress_snapshot(job))

            tester = StoredXSSTester(
                session, VERIFIER, timeout=cfg.timeout, on_event=on_stored_event,
                on_progress=on_stored_progress, concurrency=VERIFIER.pool_size,
                should_stop=lambda: job.stop_event.is_set(),
            )
            candidate_pages = [e["url"] for e in job.endpoints]
            stored_results = tester.test_points(points, candidate_pages)
            for sf in stored_results:
                d = _stored_finding_to_dict(sf)
                with job.lock:
                    job._finding_counter += 1
                    d["id"] = job._finding_counter
                    job.stored_findings.append(d)
                job.publish("stored_finding", d)

        dom_results = []
        if cfg.test_dom_xss and not stopped_early:
            job.set_phase("dom_testing")
            job.publish("state", {"phase": "dom_testing", **_progress_snapshot(job)})
            if not VERIFIER.available:
                job.publish("activity", {
                    "text": "no headless browser available -- DOM-XSS probing skipped "
                            "entirely (it has no server-side fallback; run: "
                            "playwright install chromium)"})
            else:
                def on_dom_event(msg: str) -> None:
                    job.publish("activity", {"text": msg})

                cookies, headers = _session_cookies_headers(session)
                param_names_by_url: dict[str, list[str]] = {}
                for p in points:
                    param_names_by_url.setdefault(p.url, [])
                    param_names_by_url[p.url].extend(
                        n for n in p.param_names if n not in param_names_by_url[p.url])
                page_urls = list(dict.fromkeys(
                    [e["url"] for e in job.endpoints] + list(getattr(crawler, "seen", []))))

                with job.lock:
                    job.dom_total = min(len(page_urls), 60)   # mirrors domxss.MAX_PAGES

                def on_dom_progress() -> None:
                    with job.lock:
                        job.dom_done += 1
                    job.publish("progress_update", _progress_snapshot(job))

                dom_tester = DomXSSTester(
                    VERIFIER, cookies=cookies, headers=headers, on_event=on_dom_event,
                    on_progress=on_dom_progress, concurrency=VERIFIER.pool_size,
                    should_stop=lambda: job.stop_event.is_set(),
                )
                dom_results = dom_tester.test_pages(page_urls, param_names_by_url)
                for df in dom_results:
                    d = _dom_finding_to_dict(df)
                    with job.lock:
                        job._finding_counter += 1
                        d["id"] = job._finding_counter
                        job.dom_findings.append(d)
                    job.publish("dom_finding", d)

        # Build the report only now, once verification and stored/DOM-XSS
        # testing have all had their say -- this is the artifact that gets
        # archived/emailed, so it must match what the dashboard showed, not
        # a snapshot from before confirmation ran.
        report = ScanReport.from_result(result)
        json_path = REPORTS_DIR / f"{job.id}.json"
        html_path = REPORTS_DIR / f"{job.id}.html"
        report.to_json(str(json_path))
        report.to_html(str(html_path))
        _augment_report_files(json_path, html_path, stored_results, dom_results,
                              report, len(job.endpoints))
        with job.lock:
            job.report = report

        final_phase = "stopped" if (stopped_early or job.stop_event.is_set()) else "done"
        with job.lock:
            job.finished_at = time.time()
        job.set_phase(final_phase)
        job.publish("state", {"phase": final_phase, "stats": report.stats, **_progress_snapshot(job)})
    except Exception as e:                       # a scan must never crash the server
        log.exception("scan job %s failed", job.id)
        with job.lock:
            job.error = str(e)
            job.finished_at = time.time()
        job.set_phase("error")
        job.publish("state", {"phase": "error", "error": str(e), **_progress_snapshot(job)})


def _stored_finding_to_dict(sf: StoredFinding) -> dict:
    return {
        "field": sf.field, "submission_url": sf.submission_url,
        "method": sf.method, "payload": sf.payload, "category": sf.category,
        "verified": sf.verified, "checked": sf.checked,
        "display_url": sf.display_url, "evidence": sf.evidence,
    }


def _dom_finding_to_dict(df: DomFinding) -> dict:
    return {
        "url": df.url, "technique": df.technique, "payload": df.payload,
        "injection_point": df.injection_point, "verified": df.verified,
        "checked": df.checked, "evidence": df.evidence,
    }


def _overview_cards_html(report: ScanReport, stored_dicts: list, dom_dicts: list,
                          total_endpoints: int) -> str:
    """Build the same stat cards the live 'Overview' tab shows once a scan
    finishes, so the downloaded report matches what was on screen instead
    of only the narrower reflected-XSS stats the base template knows about."""
    s = report.stats
    reflected_confirmed = s.get("confirmed", 0)
    stored_confirmed = sum(1 for d in stored_dicts if d.get("verified"))
    dom_confirmed = sum(1 for d in dom_dicts if d.get("verified"))
    confirmed_total = reflected_confirmed + stored_confirmed + dom_confirmed
    heuristic = sum(1 for f in report.deduped if f.exploitable and not f.confirmed)

    items = [
        (s.get("requests_sent", 0), "requests sent", ""),
        (total_endpoints, "endpoints tested", ""),
        (confirmed_total, "confirmed XSS", "sev-hi"),
        (0, "verifying", ""),
        (heuristic, "heuristic candidates", "sev-me"),
        (len(stored_dicts), "stored tested", ""),
        (len(dom_dicts), "DOM probes fired", ""),
        (f"{report.duration:.1f}s", "duration", ""),
        (s.get("errors", 0), "transport errors", "err"),
    ]
    cards = "".join(
        f'<div class="card {cls}"><b>{val}</b><span>{label}</span></div>'
        for val, label, cls in items
    )
    return f'<section class="cards">{cards}</section>'


def _augment_report_files(json_path: Path, html_path: Path,
                          stored_results: list, dom_results: list,
                          report: Optional["ScanReport"] = None,
                          total_endpoints: int = 0) -> None:
    """Fold stored-XSS and DOM-XSS results into the already-written
    JSON/HTML report files, so an archived/downloaded report is a
    complete artifact -- not just the reflected findings the base
    ScanReport template knows about. Also rebuilds the overview stat
    cards to match the live dashboard's Overview tab (total confirmed
    across all XSS types, endpoints tested, stored/DOM counts)."""
    stored_dicts = [_stored_finding_to_dict(sf) for sf in stored_results]
    dom_dicts = [_dom_finding_to_dict(df) for df in dom_results]

    try:
        data = json.loads(json_path.read_text(encoding="utf-8"))
        data["stored_findings"] = stored_dicts
        data["dom_findings"] = dom_dicts
        json_path.write_text(json.dumps(data, indent=2, ensure_ascii=False),
                             encoding="utf-8")
    except Exception as e:
        log.warning("could not augment JSON report with stored/DOM findings: %s", e)

    try:
        html = html_path.read_text(encoding="utf-8")

        if report is not None:
            import re
            new_cards = _overview_cards_html(report, stored_dicts, dom_dicts,
                                             total_endpoints)
            html = re.sub(r'<section class=cards>.*?</section>', new_cards,
                          html, count=1, flags=re.S)

        sections = ""

        if stored_dicts:
            confirmed = [s for s in stored_dicts if s["verified"]]
            other = [s for s in stored_dicts if not s["verified"]]
            rows = "\n".join(_stored_row_html(s) for s in confirmed + other)
            sections += f"""
<section>
  <h2>Stored XSS ({len(stored_dicts)} tested, {len(confirmed)} confirmed)</h2>
  <table>
    <thead><tr><th>Status</th><th>Field</th><th>Submission URL</th><th>Method</th>
      <th>Payload</th><th>Display URL</th><th>Evidence</th></tr></thead>
    <tbody>
{rows if rows else '<tr><td colspan=7 class=muted>No stored-XSS candidates found.</td></tr>'}
    </tbody>
  </table>
</section>
"""
        if dom_dicts:
            confirmed_dom = [d for d in dom_dicts if d["verified"]]
            rows_dom = "\n".join(_dom_row_html(d) for d in confirmed_dom)
            sections += f"""
<section>
  <h2>DOM-based XSS ({len(confirmed_dom)} confirmed)</h2>
  <p class=muted>Pages probed with client-side-only payloads (query params,
     URL fragment, hashchange, javascript: href) -- these never touch the
     server, so only confirmed execution is listed here.</p>
  <table>
    <thead><tr><th>URL</th><th>Technique</th><th>Injection point</th>
      <th>Payload</th><th>Evidence</th></tr></thead>
    <tbody>
{rows_dom if rows_dom else '<tr><td colspan=5 class=muted>No confirmed DOM-based XSS.</td></tr>'}
    </tbody>
  </table>
</section>
"""
        if sections:
            html = html.replace("</body></html>", sections + "\n</body></html>")
            html_path.write_text(html, encoding="utf-8")
    except Exception as e:
        log.warning("could not augment HTML report with stored/DOM findings: %s", e)


def _stored_row_html(s: dict) -> str:
    # local import to avoid a top-level cycle
    from xsscan.reporter import esc, _copy_cell, _copy_btn
    status = "STORED XSS CONFIRMED" if s["verified"] else (
        "stored, not executed" if s["display_url"] else "not stored")
    sev_cls = "sev-high" if s["verified"] else "sev-muted"
    status_cls = "confirmed" if s["verified"] else "not_confirmed"
    return (f'<tr class="finding-row {sev_cls} status-{status_cls}"><td><span class=badge>{esc(status)}</span></td>'
            f'<td class=mono>{esc(s["field"])}</td>'
            f'<td class=mono>{_copy_cell(s["submission_url"], s["submission_url"], "URL")}</td>'
            f'<td>{esc(s["method"])}</td>'
            f'<td class=mono>{_copy_cell(s["payload"], s["payload"], "payload")}</td>'
            f'<td class=mono>{_copy_cell(s["display_url"] or "", s["display_url"] or "", "URL") if s["display_url"] else ""}</td>'
            f'<td class=muted>{esc(s["evidence"])}</td></tr>')


def _dom_row_html(d: dict) -> str:
    # local import to avoid a top-level cycle
    from xsscan.reporter import esc, _copy_cell, _copy_btn
    return (f'<tr class="finding-row sev-high status-confirmed"><td class=mono>{_copy_cell(d["url"], d["url"], "URL")}</td>'
            f'<td>{esc(d["technique"])}</td>'
            f'<td>{esc(d["injection_point"])}</td>'
            f'<td class=mono>{_copy_cell(d["payload"], d["payload"], "payload")}</td>'
            f'<td class=muted>{esc(d["evidence"])}</td></tr>')


# ---------------------------------------------------------------------- #
# API routes
# ---------------------------------------------------------------------- #
@app.post("/api/scans")
def create_scan(cfg: ScanConfig):
    if not cfg.url.strip():
        raise HTTPException(400, "Target URL is required.")
    if not cfg.authorized:
        raise HTTPException(
            400, "You must confirm you're authorized to test this target.")

    job_id = uuid.uuid4().hex[:12]
    job = ScanJob(job_id, cfg)
    with JOBS_LOCK:
        JOBS[job_id] = job
    threading.Thread(target=_run_job, args=(job,), daemon=True).start()
    return {"id": job_id}


@app.get("/api/scans")
def list_scans():
    with JOBS_LOCK:
        jobs = list(JOBS.values())
    jobs.sort(key=lambda j: j.started_at, reverse=True)
    return [j.to_dict() for j in jobs]


def _get_job(job_id: str) -> ScanJob:
    job = JOBS.get(job_id)
    if job is None:
        raise HTTPException(404, "scan not found")
    return job


@app.get("/api/scans/{job_id}")
def get_scan(job_id: str):
    return _get_job(job_id).to_dict()


@app.get("/api/verifier")
def verifier_status():
    return {"available": VERIFIER.available}


@app.post("/api/scans/{job_id}/pause")
def pause_scan(job_id: str):
    job = _get_job(job_id)
    if job.phase not in RUNNING_PHASES:
        raise HTTPException(400, f"scan is not running (phase={job.phase})")
    job.pause_event.clear()
    with job.lock:
        job.paused = True
    job.publish("state", {"phase": job.phase, "paused": True, **_progress_snapshot(job)})
    return {"ok": True}


@app.post("/api/scans/{job_id}/resume")
def resume_scan(job_id: str):
    job = _get_job(job_id)
    job.pause_event.set()
    with job.lock:
        job.paused = False
    job.publish("state", {"phase": job.phase, "paused": False, **_progress_snapshot(job)})
    return {"ok": True}


@app.post("/api/scans/{job_id}/stop")
def stop_scan(job_id: str):
    job = _get_job(job_id)
    if job.phase not in RUNNING_PHASES:
        raise HTTPException(400, f"scan is not running (phase={job.phase})")
    job.stop_event.set()
    job.pause_event.set()          # unblock a paused worker so it can exit
    with job.lock:
        job.paused = False
    job.publish("state", {"phase": job.phase, "stopping": True, **_progress_snapshot(job)})
    return {"ok": True}


@app.get("/api/scans/{job_id}/findings")
def get_findings(job_id: str):
    job = _get_job(job_id)
    with job.lock:
        findings = list(job.findings)
        stored_findings = list(job.stored_findings)
        dom_findings = list(job.dom_findings)
        endpoints = list(job.endpoints)
        errors = ([
            {"url": u, "param": p, "payload": pl, "error": err}
            for u, p, pl, err in job.report.errors
        ] if job.report is not None else [])
    return {
        "findings": findings, "stored_findings": stored_findings,
        "dom_findings": dom_findings,
        "endpoints": endpoints, "errors": errors,
    }


@app.get("/api/scans/{job_id}/events")
def stream(job_id: str):
    job = _get_job(job_id)

    def gen():
        q = job.subscribe()
        try:
            yield ": connected\n\n"
            while True:
                try:
                    ev = q.get(timeout=15)
                    payload = json.dumps(ev["data"], ensure_ascii=False)
                    yield f"event: {ev['type']}\ndata: {payload}\n\n"
                except queue.Empty:
                    yield ": keepalive\n\n"
        finally:
            job.unsubscribe(q)

    return StreamingResponse(
        gen(), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/api/scans/{job_id}/report.json")
def download_json(job_id: str):
    path = REPORTS_DIR / f"{job_id}.json"
    if not path.exists():
        raise HTTPException(404, "report not ready yet")
    return FileResponse(path, filename=f"xsscan-{job_id}.json",
                        media_type="application/json")


@app.get("/api/scans/{job_id}/report.html")
def download_html(job_id: str):
    path = REPORTS_DIR / f"{job_id}.html"
    if not path.exists():
        raise HTTPException(404, "report not ready yet")
    return FileResponse(path, filename=f"xsscan-{job_id}.html",
                        media_type="text/html")


@app.delete("/api/scans/{job_id}")
def delete_scan(job_id: str):
    with JOBS_LOCK:
        job = JOBS.pop(job_id, None)
    if job is None:
        raise HTTPException(404, "scan not found")
    if job.phase in RUNNING_PHASES:
        job.stop_event.set()
        job.pause_event.set()
    for ext in ("json", "html"):
        p = REPORTS_DIR / f"{job_id}.{ext}"
        if p.exists():
            p.unlink()
    return {"ok": True}


# Static dashboard (mounted last so /api/* above takes priority)
app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")


def _open_browser(port: int) -> None:
    time.sleep(1.2)
    webbrowser.open(f"http://127.0.0.1:{port}")


if __name__ == "__main__":
    import uvicorn

    PORT = 8765
    threading.Thread(target=_open_browser, args=(PORT,), daemon=True).start()
    print(f"[*] xsscan console starting at http://127.0.0.1:{PORT}")
    uvicorn.run(app, host="127.0.0.1", port=PORT, log_level="info")
