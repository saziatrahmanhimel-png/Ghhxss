"""Stored XSS tester.

Submits a uniquely-marked, self-executing payload into each fuzzable
field of every form the crawler discovered, then revisits candidate
pages (the submission response itself, plus every other page already
discovered during the crawl) looking for that exact marker rendered
back. Finding the marker text on a page is NOT enough to call it stored
XSS -- that only proves the text was *stored*, not that it *executes*.
The page is then loaded in the same headless-browser Verifier used for
reflected findings, and only a real, marker-matching JavaScript dialog
counts as confirmed.

    submit -> look for marker on candidate pages -> found?
                                                      |
                                              load page in headless
                                              browser, check dialog
                                                      |
                                        dialog w/ marker -> CONFIRMED
                                          no dialog      -> stored but
                                                            not executed
"""
from __future__ import annotations

import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Callable, Optional

import requests

from .verifier import Verifier, marker_id

log = logging.getLogger("xsscan.stored")

MAX_CANDIDATE_PAGES = 40   # cap how many already-discovered pages we re-fetch per probe
DEFAULT_CONCURRENCY = 4    # (point, param) pairs tested at once -- each
                           # confirmed hit's verify_stored() call lands on
                           # the Verifier's browser-worker pool, so this
                           # should roughly track Verifier.pool_size


def _stored_payloads(token: str) -> list[tuple[str, str]]:
    """A small, self-triggering payload set (no click/interaction needed)
    for stored testing -- kept short so a submit+revisit round stays fast."""
    return [
        (f"<script>alert('{token}')</script>", "script"),
        (f'<img src=x onerror="alert(\'{token}\')">', "event"),
        (f'<svg onload="alert(\'{token}\')">', "event"),
    ]


@dataclass
class StoredFinding:
    field: str
    submission_url: str
    method: str
    payload: str
    category: str
    verified: bool               # True only if a real dialog fired with the matching marker
    checked: bool                # False if verification couldn't be attempted (no browser)
    display_url: Optional[str]   # where the marker was found rendered, if anywhere
    evidence: str


class StoredXSSTester:
    def __init__(self, session: requests.Session, verifier: Verifier, *,
                 timeout: float = 10.0,
                 concurrency: int = DEFAULT_CONCURRENCY,
                 on_event: Optional[Callable[[str], None]] = None,
                 on_progress: Optional[Callable[[], None]] = None,
                 should_stop: Optional[Callable[[], bool]] = None):
        self.session = session
        self.verifier = verifier
        self.timeout = timeout
        self.concurrency = max(1, concurrency)
        self.on_event = on_event
        self.on_progress = on_progress
        self.should_stop = should_stop or (lambda: False)

    def _emit(self, msg: str) -> None:
        if self.on_event:
            try:
                self.on_event(msg)
            except Exception:
                pass

    def test_points(self, points, candidate_pages: list) -> list[StoredFinding]:
        """`points`: the crawler's InjectionPoint list -- only source=="form"
        entries are tested (that's what "submit" means here). `candidate_pages`:
        every URL already discovered during the crawl, checked after each
        submission since stored content often renders on a different page
        (profile, listing, thread) than the one the form posted to.

        Each (point, param) pair is independent -- different field, own
        submission -- so they're tested concurrently (bounded by
        `concurrency`) instead of one at a time. The requests.Session is
        shared but, like the reflected-XSS Scanner, that's safe for
        concurrent GET/POST; only the final browser confirmation for a
        candidate serializes further, through the Verifier's own worker
        pool."""
        pairs = [(point, param) for point in points
                if getattr(point, "source", "") == "form"
                for param in point.param_names]
        if not pairs:
            return []

        out: list[StoredFinding] = []
        out_lock = threading.Lock()

        def _run_one(pair) -> None:
            if self.should_stop():
                return
            point, param = pair
            findings = self._test_one(point, param, candidate_pages)
            with out_lock:
                out.extend(findings)
            if self.on_progress:
                try:
                    self.on_progress()
                except Exception:
                    pass

        if self.concurrency == 1 or len(pairs) == 1:
            for pair in pairs:
                _run_one(pair)
        else:
            with ThreadPoolExecutor(max_workers=self.concurrency) as pool:
                list(pool.map(_run_one, pairs))
        return out

    def _test_one(self, point, param, candidate_pages) -> list[StoredFinding]:
        results = []
        for payload, category in _stored_payloads(marker_id()):
            token = payload.split("'")[1]     # the marker embedded just above
            params = dict(point.params)
            params[param] = payload
            try:
                if point.method == "POST":
                    resp = self.session.post(point.url, data=params,
                                             timeout=self.timeout, allow_redirects=True)
                else:
                    resp = self.session.get(point.url, params=params,
                                            timeout=self.timeout, allow_redirects=True)
            except requests.RequestException as e:
                self._emit(f"stored probe submit failed for {param}: {e}")
                continue

            self._emit(f"submitted stored probe -> {point.method} {point.url} field={param}")

            pages_to_check = [resp.url] + [u for u in candidate_pages if u != resp.url]
            found_on = None
            for page_url in pages_to_check[:MAX_CANDIDATE_PAGES]:
                html = self._fetch_html(page_url)
                if html and token in html:
                    found_on = page_url
                    break

            if found_on is None:
                results.append(StoredFinding(
                    field=param, submission_url=point.url, method=point.method,
                    payload=payload, category=category, verified=False, checked=True,
                    display_url=None,
                    evidence="payload text was not found on any revisited page "
                             "(not stored, or stored somewhere outside the crawl scope)"))
                continue

            self._emit(f"stored marker found rendered at {found_on} -- verifying execution")
            if not self.verifier.available:
                results.append(StoredFinding(
                    field=param, submission_url=point.url, method=point.method,
                    payload=payload, category=category, verified=False, checked=False,
                    display_url=found_on,
                    evidence="payload is stored and rendered back, but execution "
                             "could not be verified (no headless browser available)"))
                continue

            vr = self.verifier.verify_stored(
                found_on, self.session.cookies.get_dict(),
                {k: v for k, v in self.session.headers.items()
                 if k.lower() != "user-agent"}, marker=token)
            results.append(StoredFinding(
                field=param, submission_url=point.url, method=point.method,
                payload=payload, category=category, verified=vr.verified,
                checked=vr.checked, display_url=found_on,
                evidence=vr.evidence or vr.error))
        return results

    def _fetch_html(self, url: str) -> Optional[str]:
        try:
            r = self.session.get(url, timeout=self.timeout)
            return r.text
        except requests.RequestException:
            return None
