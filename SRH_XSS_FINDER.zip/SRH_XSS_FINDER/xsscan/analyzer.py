"""Analyzer: reflection detection, context classification, exploitability scoring.

Given a RequestContext (what was injected, where, in which encoding) and the
HTTP response, the analyzer:

  1. Locates the payload in the response body at several decoding stages
     (raw, URL-decoded, HTML-entity-decoded, double-URL-decoded), so
     reflections that come back encoded by the application are still caught.
  2. Filters against the baseline response captured during crawling --
     occurrences already present in the page's static content (menus,
     scripts, sample text) are subtracted, which is the main defense
     against false positives.
  3. Classifies the surrounding context by parsing the HTML around the
     byte offset: element text, comment, attribute (quoted/unquoted/URL),
     <script> block, JS string, event handler, raw-text element (textarea
     etc.), or CSS.
  4. Scores exploitability with a (context, payload category) rule matrix,
     then adjusts confidence for encoding stage, status code, baseline
     presence, CSP/X-XSS-Protection headers, and redirect behavior.

The classifier is heuristic by design: it parses the *raw* HTML text
around the offset instead of running a full DOM. It is fast and good
enough to separate "reflected raw into element text" (likely XSS) from
"reflected HTML-escaped into a quoted attribute" (likely not), which is
the 95% case. Ambiguous contexts are flagged for manual review instead
of being silently classified.
"""
from __future__ import annotations

import html as html_mod
import logging
import re
import urllib.parse
from dataclasses import dataclass, field
from typing import Optional

import requests

from .scanner import RequestContext

log = logging.getLogger("xsscan.analyzer")

# URL attributes where a javascript: URI executes on click/load.
URL_ATTRS = {
    "href", "src", "action", "formaction", "data", "background", "poster",
    "cite", "longdesc", "usemap", "codebase", "dynsrc", "lowsrc", "profile",
    "xlink:href", "srcset",
}

# Raw-text elements: content parsed as text, need </tag> breakout.
RAWTEXT_TAGS = ("textarea", "title", "xmp", "noembed", "noscript",
                "iframe", "plaintext")

CONTEXT_LABELS = {
    "html_body": "HTML element text",
    "html_comment": "HTML comment",
    "html_tag_inner": "Inside tag, outside attribute value",
    "attr_dq": "Double-quoted attribute",
    "attr_sq": "Single-quoted attribute",
    "attr_unquoted": "Unquoted attribute value",
    "attr_url": "URL attribute (href/src/action)",
    "js_script": "Inside <script> element",
    "js_string_dq": "JS string (double quotes)",
    "js_string_sq": "JS string (single quotes)",
    "js_string_tpl": "JS template literal",
    "js_event_handler": "Event handler attribute (on*)",
    "style": "CSS context",
    "non_html": "Non-HTML response body",
    "unknown": "Unknown context",
}

# Order of evidence strength for the same byte offset.
STAGE_PRIORITY = {
    "raw": 0, "literal": 1, "html_decoded": 2, "url_encoded": 3,
    "double_url_encoded": 4, "decoded": 5, "partial": 6,
}


@dataclass
class AnalyzerConfig:
    report_encoded_only: bool = True     # keep findings where reflection was encoded
    report_partial: bool = True          # keep partial (filtered) reflections
    min_confidence: float = 0.0
    max_body: int = 2_000_000
    consider_url_encoded: bool = True


@dataclass
class Finding:
    """One confirmed reflection of an injected payload."""
    url: str
    method: str
    param: str
    payload: str
    variant: str
    category: str
    description: str
    reflected: bool
    exploitable: bool
    confidence: float
    context: str
    context_label: str
    matched_as: str
    offset: int
    length: int
    snippet: str
    occurrences: list                      # [(stage, start, end), ...]
    status: int
    response_url: str
    baseline_present: bool
    notes: list
    security_headers: dict = field(default_factory=dict)

    # Populated by the optional browser-verification stage (xsscan/verifier.py).
    # False/"" until something actually re-runs this payload in a real browser
    # and observes it execute -- reflected/exploitable above are still just
    # the static heuristic and must not be reported as "XSS confirmed" on
    # their own.
    confirmed: bool = False
    execution_evidence: str = ""

    @property
    def key(self) -> tuple:
        return (self.url, self.method, self.param)


class Analyzer:
    def __init__(self, config: Optional[AnalyzerConfig] = None):
        self.config = config or AnalyzerConfig()

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def analyze(self, context: RequestContext,
                response: requests.Response) -> Optional[Finding]:
        """Return a Finding if the payload (or an encoded/partial form of
        it) appears in the response, else None."""
        try:
            body = response.text
        except Exception as e:
            log.debug("cannot decode body for %s: %s", response.url, e)
            return None
        if self.config.max_body and len(body) > self.config.max_body:
            body = body[: self.config.max_body]

        baseline = ""
        if context.point.response is not None:
            try:
                baseline = context.point.response.text
            except Exception:
                baseline = ""

        matches = self._find_matches(body, context)
        if not matches:
            return None
        matches, baseline_present = self._filter_baseline(
            matches, baseline, context.payload)
        if not matches:
            return None
        matches = self._dedupe(matches)
        matches.sort(key=lambda m: (m[1], m[2]))

        primary = min(matches, key=lambda m: (STAGE_PRIORITY[m[0]], m[1], m[2]))
        stage, start, end, hay = primary

        is_html = self._is_html(response, body)
        ctx = self.classify_context(hay, start, end) if is_html else "non_html"

        exploitable, confidence, notes = self._score(
            ctx, context.category, context.payload, stage,
            response.status_code)

        # --- evidence / adjustment pass ---
        if context.variant != "raw":
            notes.append(f"payload was sent as a {context.variant}-encoded literal")
        if stage in ("url_encoded", "double_url_encoded"):
            notes.append("reflection arrived URL-encoded (server re-encodes "
                         "input) -- only sinks that decode again may execute")
        elif stage == "html_decoded":
            notes.append("reflection decodes from HTML entities -- application "
                         "decodes input instead of escaping output (weak encoding)")
        if stage == "partial":
            notes.append("only part of the payload was reflected -- an input "
                         "filter or WAF is likely stripping characters")
        if not is_html:
            notes.append("response is not HTML; exploitability depends on a "
                         "downstream sink (DOM) rendering this body")
        if response.url != context.request_url:
            notes.append(f"request redirected {len(response.history)}x to "
                         f"{response.url}")
            if context.payload[:16] in response.url:
                notes.append("payload fragment present in the final URL -- "
                             "server reflects input into the Location/URL")

        headers = self._security_headers(response)
        if "Content-Security-Policy" in headers:
            notes.append("CSP present -- may block execution even when reflection "
                         "is unencoded; check policy for script-src bypasses")
        if headers.get("X-XSS-Protection", "").startswith("1"):
            notes.append("X-XSS-Protection: 1 -- legacy filter may mangle "
                         "payloads; not a security boundary")

        confidence = max(0.0, min(1.0, round(confidence, 2)))
        if confidence < self.config.min_confidence:
            return None

        return Finding(
            url=context.point.url, method=context.point.method,
            param=context.param, payload=context.payload,
            variant=context.variant, category=context.category,
            description=context.description,
            reflected=True, exploitable=exploitable,
            confidence=confidence, context=ctx,
            context_label=CONTEXT_LABELS.get(ctx, ctx),
            matched_as=stage, offset=start, length=end - start,
            snippet=self._snippet(hay, start, end),
            occurrences=[(s, a, b) for s, a, b, _ in matches][:20],
            status=response.status_code, response_url=response.url,
            baseline_present=baseline_present, notes=notes,
            security_headers=headers,
        )

    # ------------------------------------------------------------------ #
    # Matching
    # ------------------------------------------------------------------ #
    def _find_matches(self, body: str, context: RequestContext):
        """All (stage, start, end, haystack) occurrences of the payload."""
        out = []
        if context.variant == "raw":
            stages = [("raw", body)]
            if self.config.consider_url_encoded:
                stages += [
                    ("url_encoded", urllib.parse.unquote(body)),
                    ("html_decoded", html_mod.unescape(body)),
                    ("double_url_encoded",
                     urllib.parse.unquote(urllib.parse.unquote(body))),
                ]
            for stage, hay in stages:
                out += self._scan(hay, context.payload, stage)
        else:
            # pre-encoded literal: may come back verbatim (raw reflection)
            # or decoded by the server (weak input handling)
            out += self._scan(body, context.payload, "literal")
            dec_url = urllib.parse.unquote(context.payload)
            if dec_url != context.payload:
                out += self._scan(urllib.parse.unquote(body), dec_url, "decoded")
            dec_html = html_mod.unescape(context.payload)
            if dec_html != context.payload:
                out += self._scan(html_mod.unescape(body), dec_html, "decoded")

        if not out and self.config.report_partial:
            prefix = context.payload[: max(12, len(context.payload) // 2)]
            if len(prefix) >= 10:
                out += self._scan(body, prefix, "partial")
        return out

    @staticmethod
    def _scan(hay: str, needle: str, stage: str):
        return [(stage, m.start(), m.end(), hay)
                for m in re.finditer(re.escape(needle), hay)]

    def _filter_baseline(self, matches, baseline: str, payload: str):
        """Subtract occurrences that already exist in the baseline page."""
        if not baseline:
            return matches, False
        base_count = len(list(re.finditer(re.escape(payload), baseline)))
        if base_count == 0:
            return matches, False
        raw = [m for m in matches if m[0] == "raw"]
        non_raw = [m for m in matches if m[0] != "raw"]
        if len(raw) > base_count:
            return raw[base_count:] + non_raw, True
        # every raw hit could be static content; keep only encoded-stage hits
        return non_raw, True

    def _dedupe(self, matches):
        seen = {}
        for m in matches:
            key = (m[1], m[2])
            if key not in seen or STAGE_PRIORITY[m[0]] < STAGE_PRIORITY[seen[key][0]]:
                seen[key] = m
        return list(seen.values())

    # ------------------------------------------------------------------ #
    # Context classification
    # ------------------------------------------------------------------ #
    def classify_context(self, body: str, start: int, end: int) -> str:
        """Classify the HTML/JS context surrounding body[start:end]."""
        before = body[max(0, start - 300):start]
        after = body[end:end + 300]

        if "<!--" in before and "-->" not in after:
            return "html_comment"

        for tag in RAWTEXT_TAGS:
            open_idx = body.rfind(f"<{tag}", 0, start)
            if open_idx != -1:
                close_idx = body.find(f"</{tag}>", end)
                if close_idx == -1 or close_idx > end:
                    return f"rawtext_{tag}"

        open_idx = body.rfind("<script", 0, start)
        if open_idx != -1:
            close_idx = body.find("</script>", end)
            if close_idx == -1 or close_idx > end:
                return self._classify_js(body, start, end, open_idx, close_idx)

        style_open = body.rfind("<style", 0, start)
        if style_open != -1:
            style_close = body.find("</style>", end)
            if style_close == -1 or style_close > end:
                return "style"

        return self._classify_tag(body, start, end)

    def _classify_js(self, body, start, end, open_idx, close_idx):
        """Inside a <script> block: JS string, template literal, or raw JS?"""
        block_end = close_idx if close_idx != -1 else len(body)
        tag_end = body.find(">", open_idx)
        seg = body[tag_end + 1:start] if tag_end != -1 else body[open_idx:start]
        # strip comments so quotes inside them don't fool the scan
        seg = re.sub(r"/\*.*?\*/", "", seg, flags=re.S)
        seg = re.sub(r"//[^\n]*", "", seg)

        for q, name in (('"', "js_string_dq"), ("'", "js_string_sq"),
                        ("`", "js_string_tpl")):
            pos = self._last_unescaped(seg, q)
            if pos is None:
                continue
            after = body[end:block_end]
            after = re.sub(r"/\*.*?\*/", "", after, flags=re.S)
            if self._find_unescaped(after, q) is not None:
                return name
        return "js_script"

    def _classify_tag(self, body, start, end):
        """Reflection inside or near an HTML tag."""
        lt = body.rfind("<", 0, start)
        if lt == -1:
            return "html_body"
        gt = self._find_tag_end(body, lt)
        if gt == -1 or gt < end:
            return "html_body"
        tag_text = body[lt:gt + 1]
        rel = start - lt

        q = self._last_quote(tag_text, rel)
        if q:
            qpos, qchar = q
            eq = tag_text.rfind("=", 0, qpos)
            if eq != -1:
                name = self._attr_name_for(tag_text, eq)
                return self._attr_context(name, qchar)

        eq = tag_text.rfind("=", 0, rel)
        if eq != -1:
            seg = tag_text[eq + 1:rel]
            if " " not in seg and "\t" not in seg and "\n" not in seg:
                name = self._attr_name_for(tag_text, eq)
                if name:
                    return self._attr_context(name, None)
        return "html_tag_inner"

    def _attr_context(self, name: str, qchar: Optional[str]) -> str:
        if name in URL_ATTRS:
            return "attr_url"
        if name.startswith("on"):
            return "js_event_handler"
        if name == "style":
            return "style"
        if qchar == '"':
            return "attr_dq"
        if qchar == "'":
            return "attr_sq"
        return "attr_unquoted"

    # ------------------------------------------------------------------ #
    # Exploitability scoring
    # ------------------------------------------------------------------ #
    def _score(self, context: str, category: str, payload: str,
               matched_as: str, status: int):
        """Return (exploitable, confidence, notes) for one reflection."""
        notes = []
        exploitable = False
        conf = 0.2

        if matched_as == "partial":
            return exploitable, 0.15, [
                "payload only partially reflected -- input filter likely active"]

        # --- URL sink with javascript: scheme (works even when entities
        # --- are used, because URL parsing decodes character references)
        if context == "attr_url" and "javascript:" in payload.lower():
            exploitable = True
            conf = 0.9
            notes.append("javascript: URI reflected into a URL attribute "
                         "(href/src/action)")
            if matched_as != "raw":
                conf -= 0.2
                notes.append(f"observed as {matched_as}; browsers decode "
                             "character references during URL parsing")
            return exploitable, conf, notes

        # --- element text ---
        if context in ("html_body", "unknown"):
            if category in ("script", "event", "iframe", "mutation",
                            "mutation2") or "<" in payload:
                if matched_as == "raw":
                    exploitable = True
                    conf = 0.9
                    notes.append(f"{category} payload reflected unencoded in "
                                 "element text -- browser will parse it")
                else:
                    conf = 0.4
                    notes.append(f"reflected as {matched_as}; check whether the "
                                 "browser decodes before parsing")
            elif category == "obf_hex":
                conf = 0.2
                notes.append("hex-escaped tags in element text: character "
                             "references in text do not create elements in HTML5")
            return exploitable, conf, notes

        # --- attributes ---
        if context in ("attr_dq", "attr_sq"):
            q = '"' if context == "attr_dq" else "'"
            if q in payload:
                exploitable = True
                conf = 0.9
                notes.append(f"payload breaks out of the {q}-quoted attribute")
                if category == "attr_auto":
                    conf = min(1.0, conf + 0.05)
            else:
                conf = 0.1
                notes.append(f"no quote breakout in {q}-quoted attribute; "
                             "payload stays inert inside the value")
            return exploitable, conf, notes

        if context == "attr_unquoted":
            if category in ("script", "event", "iframe") or any(
                    c in payload for c in " /"):
                exploitable = True
                conf = 0.85
                notes.append("unquoted attribute value -- whitespace/attr "
                             "delimiters can start a new attribute")
            return exploitable, conf, notes

        # --- JavaScript contexts ---
        if context in ("js_string_sq", "js_string_dq", "js_string_tpl"):
            q = {"js_string_sq": "'", "js_string_dq": '"',
                 "js_string_tpl": "`"}[context]
            if q in payload:
                exploitable = True
                conf = 0.9
                notes.append(f"payload breaks out of the JS {q}-delimited string")
            elif category == "js_break":
                exploitable = True
                conf = 0.85
                notes.append("</script> closes the script element from inside "
                             "a JS string")
            else:
                conf = 0.1
                notes.append("no JS string breakout; payload inert inside the "
                             "string literal")
            return exploitable, conf, notes

        if context == "js_script":
            if category in ("js_break", "script", "event", "js_direct",
                            "js_expr", "mutation"):
                exploitable = True
                conf = 0.9
                notes.append(f"payload lands in raw JS execution context ({category})")
            else:
                conf = 0.4
                notes.append("payload in JS context but shape may not execute "
                             "as written -- review manually")
            return exploitable, conf, notes

        if context == "js_event_handler":
            if category in ("js_direct", "script", "event", "js_expr",
                            "js_break", "url_js", "url_js_comment"):
                exploitable = True
                conf = 0.9
                notes.append("payload in an event handler attribute -- "
                             "executes as JavaScript")
            return exploitable, conf, notes

        # --- comments / raw-text elements ---
        if context == "html_comment":
            if "-->" in payload:
                exploitable = True
                conf = 0.8
                notes.append("payload closes the HTML comment with -->")
            else:
                conf = 0.1
                notes.append("reflection inside an HTML comment; needs --> breakout")
            return exploitable, conf, notes

        if context.startswith("rawtext_"):
            tag = context.split("_", 1)[1]
            if f"</{tag}>" in payload:
                exploitable = True
                conf = 0.8
                notes.append(f"payload closes the <{tag}> raw-text element")
            else:
                conf = 0.1
                notes.append(f"reflection inside <{tag}>; needs </{tag}> breakout")
            return exploitable, conf, notes

        if context in ("style",):
            conf = 0.15
            notes.append("reflection in CSS context -- rarely exploitable in "
                         "modern browsers")
            return exploitable, conf, notes

        if context == "non_html":
            conf = 0.2
            notes.append("non-HTML response -- exploitability depends on a "
                         "downstream DOM sink rendering this body")
            return exploitable, conf, notes

        notes.append(f"unclassified context ({context}) -- manual review recommended")
        return exploitable, conf, notes

    # ------------------------------------------------------------------ #
    # Small helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def _snippet(hay: str, start: int, end: int, pad: int = 60) -> str:
        a = max(0, start - pad)
        b = min(len(hay), end + pad)
        return f"{hay[a:start]}<<<{hay[start:end]}>>>{hay[end:b]}"

    @staticmethod
    def _security_headers(response) -> dict:
        out = {}
        for key in ("Content-Security-Policy", "X-XSS-Protection",
                    "X-Content-Type-Options"):
            val = response.headers.get(key)
            if val is None:
                for hk, hv in response.headers.items():
                    if hk.lower() == key.lower():
                        val = hv
                        break
            if val is not None:
                out[key] = val
        return out

    @staticmethod
    def _is_html(response, body: str) -> bool:
        ctype = response.headers.get("Content-Type", "").lower()
        if "html" in ctype:
            return True
        if ctype and not ctype.startswith("text/"):
            return False
        head = body.lstrip()[:128].lower()
        return head.startswith(("<html", "<!doctype"))

    @staticmethod
    def _last_unescaped(s: str, ch: str) -> Optional[int]:
        i = len(s) - 1
        while i >= 0:
            if s[i] == ch:
                bs = 0
                j = i - 1
                while j >= 0 and s[j] == "\\":
                    bs += 1
                    j -= 1
                if bs % 2 == 0:
                    return i
            i -= 1
        return None

    @staticmethod
    def _find_unescaped(s: str, ch: str) -> Optional[int]:
        for i, c in enumerate(s):
            if c == ch:
                bs = 0
                j = i - 1
                while j >= 0 and s[j] == "\\":
                    bs += 1
                    j -= 1
                if bs % 2 == 0:
                    return i
        return None

    @staticmethod
    def _last_quote(tag_text: str, rel: int):
        i = rel - 1
        while i >= 0:
            c = tag_text[i]
            if c in ('"', "'"):
                bs = 0
                j = i - 1
                while j >= 0 and tag_text[j] == "\\":
                    bs += 1
                    j -= 1
                if bs % 2 == 0:
                    return (i, c)
            i -= 1
        return None

    @staticmethod
    def _attr_name_for(tag_text: str, eq_pos: int) -> str:
        if eq_pos <= 0:
            return ""
        seg_start = 0
        for c in (" ", ">", '"', "'", "\t", "\n", "\r", "/"):
            idx = tag_text.rfind(c, 0, eq_pos)
            if idx != -1 and idx > seg_start:
                seg_start = idx
        return tag_text[seg_start + 1:eq_pos].strip().lower()

    @staticmethod
    def _find_tag_end(body: str, lt: int) -> int:
        q = None
        for i in range(lt + 1, len(body)):
            c = body[i]
            if q:
                if c == q:
                    q = None
            elif c in ('"', "'"):
                q = c
            elif c == ">":
                return i
        return -1
