"""xsscan -- automated reflected XSS scanner for authorized testing.

Pipeline: Crawler (discovery) -> Scanner (injection) -> Analyzer
(reflection/context detection) -> Reporter (JSON/HTML output).
"""
__version__ = "0.1.0"

from .analyzer import Analyzer, AnalyzerConfig, Finding       # noqa: F401
from .crawler import Crawler, InjectionPoint                  # noqa: F401
from .reporter import ScanReport                              # noqa: F401
from .scanner import RequestContext, ScanResult, Scanner      # noqa: F401
