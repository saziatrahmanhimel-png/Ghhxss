"""CLI entry point for xsscan.

Wires the full pipeline end to end:

    session -> crawler -> scanner -> analyzer -> reporter

Supports a plain scanner run, or a "verify" mode that re-issues the
specific requests behind each finding (raw HTTP request/response pairs,
with a copy-paste curl command) for manual validation and remediation
handoff.

Exit codes:
    0  scan completed, nothing exploitable found (or --no-fail used)
    1  scan completed, exploitable reflections found
    2  CLI/config error
    3  scan aborted mid-way (transport/interrupt issues)
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from typing import Optional

import requests

from . import __version__
from .analyzer import Analyzer, AnalyzerConfig
from .crawler import Crawler
from .reporter import ScanReport, severity_of
from .scanner import Scanner

log = logging.getLogger("xsscan.cli")


# ---------------------------------------------------------------------- #
# Argument parsing
# ---------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="xsscan",
        description="Automated reflected XSS scanner for authorized "
                    "penetration testing.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("url", help="Target URL, e.g. https://app.example.com/")
    p.add_argument("--verify", action="store_true",
                   help="after scanning, re-issue the exact requests behind "
                        "each finding and print raw HTTP pairs + curl commands")

    g_scope = p.add_argument_group("crawl scope")
    p.add_argument("--scope", choices=["host", "prefix", "all"],
                   default="host",
                   help="host=same host only; prefix=same path subtree; "
                        "all=cross-host (use only with authorization)")
    p.add_argument("--depth", type=int, default=3, metavar="N",
                   help="max crawl depth (link hops from seed)")
    p.add_argument("--pages", type=int, default=100, metavar="N",
                   help="max pages to crawl")
    p.add_argument("--delay", type=float, default=0.1, metavar="SEC",
                   help="min seconds between requests (global rate limit)")

    g_perf = p.add_argument_group("performance")
    p.add_argument("--concurrency", type=int, default=4, metavar="N",
                   help="number of parallel injection workers")
    p.add_argument("--timeout", type=float, default=10.0, metavar="SEC",
                   help="per-request timeout")
    p.add_argument("--retries", type=int, default=1, metavar="N",
                   help="retries per request on transient errors")

    g_http = p.add_argument_group("HTTP")
    p.add_argument("--cookie", action="append", default=[], metavar="NAME=V",
                   help="cookie to send with every request (repeatable)")
    p.add_argument("--header", action="append", default=[], metavar="NAME: V",
                   help="extra request header (repeatable)")
    p.add_argument("--user-agent", default="xsscan/0.1 (authorized test)",
                   help="User-Agent header")
    p.add_argument("--no-verify-ssl", action="store_true",
                   help="disable TLS certificate verification")
    p.add_argument("--allow-redirects", action="store_true", default=True,
                   help=argparse.SUPPRESS)

    g_report = p.add_argument_group("output")
    p.add_argument("--json", metavar="FILE", help="write JSON report to FILE")
    p.add_argument("--html", metavar="FILE", help="write HTML report to FILE")
    p.add_argument("--no-fail", action="store_true",
                   help="always exit 0, even when exploitable findings exist "
                        "(useful for CI triage pipelines)")
    p.add_argument("-v", "--verbose", action="count", default=0,
                   help="increase logging (-v debug)")

    g_engine = p.add_argument_group("analysis tuning")
    p.add_argument("--no-encoded", action="store_true",
                   help="ignore reflections that only appear URL-encoded")
    p.add_argument("--min-confidence", type=float, default=0.0,
                   metavar="F", help="drop findings below this confidence (0-1)")
    p.add_argument("--version", action="version",
                   version=f"xsscan {__version__}")
    return p


# ---------------------------------------------------------------------- #
# Session construction
# ---------------------------------------------------------------------- #
def build_session(args) -> requests.Session:
    s = requests.Session()
    s.headers["User-Agent"] = args.user_agent
    for h in args.header:
        if ":" not in h:
            raise SystemExit(f"invalid --header (expected 'Name: value'): {h}")
        name, _, value = h.partition(":")
        s.headers[name.strip()] = value.strip()
    for c in args.cookie:
        if "=" not in c:
            raise SystemExit(f"invalid --cookie (expected 'name=value'): {c}")
        name, _, value = c.partition("=")
        s.cookies.set(name.strip(), value.strip())
    return s


# ---------------------------------------------------------------------- #
# Verify mode: re-issue the exact requests behind each finding
# ---------------------------------------------------------------------- #
def verify_findings(result, findings, session, timeout):
    """Re-issue each finding's request and print raw HTTP + curl command."""
    from .scanner import RequestContext

    print("\n" + "=" * 70)
    print("VERIFY MODE — re-issuing the exact requests behind each finding")
    print("=" * 70)

    for i, f in enumerate(findings, 1):
        ctx = RequestContext(
            point=_point_for(f),
            param=f.param, payload=f.payload, variant=f.variant,
            category=f.category, description=f.description,
        )
        url, kwargs = session, None  # placeholder; replaced below
        # Rebuild the wire request the same way the scanner did
        from .scanner import Scanner
        tmp = Scanner(session, None, timeout=timeout)
        wire_url, wire_kwargs = tmp._build_request(_point_for(f),
                                                   f.param, f.payload,
                                                   f.variant)
        method = f.method
        print(f"\n--- Finding {i}: {f.param} @ {f.url} "
              f"[{severity_of(f)}] ---")
        print(f">>> {method} {wire_url}")
        for k, v in (wire_kwargs.get("params") or {}).items():
            print(f">>>     params: {k}={v}")
        if "data" in wire_kwargs:
            body = wire_kwargs["data"]
            if isinstance(body, dict):
                body = "&".join(f"{k}={v}" for k, v in body.items())
            print(f">>>     data: {body}")
        print(f">>> curl: {curl_command(method, wire_url, wire_kwargs)}")

        try:
            resp = session.request(method, wire_url, **wire_kwargs,
                                   timeout=timeout, allow_redirects=True)
            print(f"<<< {resp.status_code} {resp.headers.get('Content-Type', '')}")
            body = resp.text
            idx = body.find(f.payload)
            if idx != -1:
                snip = body[max(0, idx - 40):idx + len(f.payload) + 40]
                print(f"<<< reflection at {idx}: ...{snip!r}...")
            else:
                dec = __import__("urllib.parse", fromlist=["unquote"]).unquote(body)
                idx = dec.find(f.payload)
                if idx != -1:
                    print("<<< reflection found (URL-decoded body)")
                else:
                    print("<<< no raw reflection in this response")
        except requests.RequestException as e:
            print(f"<<< ERROR: {e}")


def _point_for(f):
    """Rebuild a minimal InjectionPoint so the scanner can re-build the request."""
    from .crawler import InjectionPoint
    return InjectionPoint(url=f.url, method=f.method,
                          params={f.param: "x"}, param_names=[f.param],
                          source="verify")


def curl_command(method, url, kwargs) -> str:
    """Render the request as a curl command for handoff to remediation."""
    parts = [f"curl -sS -X {method}"]
    params = kwargs.get("params")
    data = kwargs.get("data")
    if params:
        parts.append(f"-G --data-urlencode '{_kv(params)}'")
    if data:
        if isinstance(data, dict):
            data = _kv(data)
        parts.append(f"--data '{data}'")
    return " ".join(parts) + f" '{url}'"


def _kv(pairs) -> str:
    if isinstance(pairs, dict):
        return "&".join(f"{k}={v}" for k, v in pairs.items())
    return str(pairs)


# ---------------------------------------------------------------------- #
# main
# ---------------------------------------------------------------------- #
def main(argv: Optional[list] = None) -> int:
    args = build_parser().parse_args(argv)

    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    try:
        session = build_session(args)
    except SystemExit as e:
        print(e, file=sys.stderr)
        return 2

    config = AnalyzerConfig(
        report_encoded_only=True,
        consider_url_encoded=not args.no_encoded,
        min_confidence=args.min_confidence,
    )

    crawler = Crawler(
        session,
        scope=args.scope,
        max_depth=args.depth,
        max_pages=args.pages,
        delay=args.delay,
        timeout=args.timeout,
        verify_ssl=not args.no_verify_ssl,
    )

    print(f"[*] xsscan {__version__} — target: {args.url}")
    print(f"[*] crawling (scope={args.scope}, depth={args.depth}, "
          f"pages={args.pages}) ...")
    try:
        points = crawler.discover(args.url)
    except requests.RequestException as e:
        print(f"[!] crawl failed: {e}", file=sys.stderr)
        return 3
    if not points:
        print("[!] no injection points discovered (no parameters or forms).")
        return 0

    print(f"[*] {len(points)} injection point(s) found — starting scan "
          f"({args.concurrency} workers, {args.delay}s throttle) ...")

    started = time.time()

    def on_progress(done, total):
        pct = done * 100 // max(total, 1)
        print(f"    [{pct:3d}%] {done}/{total} requests", end="\r")

    scanner = Scanner(
        session,
        Analyzer(config),
        concurrency=args.concurrency,
        delay=args.delay,
        timeout=args.timeout,
        retries=args.retries,
        verify_ssl=not args.no_verify_ssl,
        on_progress=on_progress,
    )
    result = scanner.scan(points)
    report = ScanReport.from_result(result)

    print("\n" + report.to_text())

    if args.html:
        report.to_html(args.html)
        print(f"[*] HTML report: {args.html}")
    if args.json:
        report.to_json(args.json)
        print(f"[*] JSON report: {args.json}")

    if args.verify and report.deduped:
        verify_findings(result, report.deduped, session, args.timeout)

    exploitable = report.stats["exploitable"]
    if exploitable and not args.no_fail:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
