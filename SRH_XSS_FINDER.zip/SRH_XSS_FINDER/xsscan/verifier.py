"""Headless-browser execution verification.

The analyzer's context/category scoring (see analyzer.py) is a strong
*heuristic* for whether a reflected or stored payload would execute --
it never actually runs a browser. That heuristic is what previously got
reported as "exploitable", which is why a payload could show up as
"found" even when it didn't really fire (e.g. a browser's HTML parser
handles the surrounding markup differently than the raw-text regex
classifier assumed).

This module closes that gap: it loads the real page in headless Chromium
(via Playwright), using the exact HTTP request the scanner used (a GET
navigation, or a real POST form submission -- not an XHR, so redirects,
cookies, and script execution all behave exactly like a normal browser),
and listens for the alert()/confirm()/prompt() call every xsscan payload
uses as its "it worked" signal.

A finding is only ever labeled CONFIRMED when a dialog actually fires.
Everything else -- reflected, stored, encoded, blocked -- is reported as
such and never silently promoted to "confirmed" by a heuristic alone.

Threading note: Playwright's *sync* API binds its browser/page objects to
whichever OS thread called sync_playwright().start() -- calling those
objects from any other thread raises
`greenlet.error: cannot switch to a different thread`. xsscan runs each
scan (and its stored/DOM-XSS testers) on its own background thread, so
every verify_* call here can arrive from a different caller thread, and
often several at once (stored/DOM testing fire off many candidates in
parallel). To stay correct while still running verifications in
parallel, this class owns a small *pool* of dedicated worker threads,
each with its own independent Chromium instance, and every public
verify_* method marshals its actual Playwright work onto whichever pool
worker is free next via a shared queue, blocking the *calling* thread
until that result comes back. Callers never need to know any of this --
verify_get/verify_post/verify_stored/verify_custom are safe to call from
any thread, any number at once.

Requires:  pip install playwright  &&  playwright install chromium
If Playwright or the Chromium binary isn't installed, verification is
skipped entirely and findings are labeled "unverified" (heuristic-only)
rather than confirmed OR rejected -- we never claim a negative result
we didn't actually check for either.
"""
from __future__ import annotations

import logging
import queue
import threading
import urllib.parse
import uuid
from dataclasses import dataclass
from typing import Callable, Optional

log = logging.getLogger("xsscan.verifier")

try:
    from playwright.sync_api import sync_playwright
    from playwright.sync_api import TimeoutError as PWTimeoutError
    PLAYWRIGHT_IMPORTABLE = True
except ImportError:
    PLAYWRIGHT_IMPORTABLE = False

    class PWTimeoutError(Exception):
        pass


def marker_id() -> str:
    """A short unique token to embed in a verification payload's alert()
    message, so a fired dialog can be matched back to the exact
    submission that produced it -- important once more than one payload
    might be live on a page at once (stored XSS, DOM-XSS probing)."""
    return "XSSPROBE-" + uuid.uuid4().hex[:10]


@dataclass
class VerificationResult:
    verified: bool                  # True only if a matching dialog actually fired
    checked: bool                   # False if verification could not be attempted at all
    evidence: str = ""
    error: str = ""


class Verifier:
    """Owns a small pool of headless Chromium instances, each pinned to
    its own dedicated worker thread (Playwright's sync API requires that).
    All public verify_* methods are safe to call from any thread; work is
    spread across whichever pool workers are free via a shared queue, so
    up to `pool_size` verifications run in parallel instead of one at a
    time -- this is normally the biggest cost in a scan (every stored-XSS
    and DOM-XSS candidate needs a real browser navigation to confirm)."""

    def __init__(self, timeout: float = 6.0, settle_wait: float = 0.6,
                 pool_size: int = 3):
        self.timeout = timeout
        self.settle_wait = settle_wait
        self.pool_size = max(1, pool_size)
        self.available = False
        self._local = threading.local()          # per-worker-thread pw/browser
        self._work_queue: "queue.Queue" = queue.Queue()
        self._worker_threads: list[threading.Thread] = []
        self._ready = threading.Event()
        self._launch_lock = threading.Lock()
        self._launched_ok = 0

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #
    def start(self) -> bool:
        """Launch the first headless Chromium worker and block (briefly)
        until it succeeds or fails -- callers should check .available and
        degrade gracefully rather than assume this always succeeds. The
        rest of the pool starts in the background right after, so start()
        doesn't have to wait on N browser launches to return."""
        if not PLAYWRIGHT_IMPORTABLE:
            log.warning(
                "playwright package not installed -- XSS execution "
                "verification disabled. Run: pip install playwright")
            self._ready.set()
            return False

        t0 = threading.Thread(target=self._worker_loop, name="xsscan-verifier-0",
                              daemon=True)
        self._worker_threads.append(t0)
        t0.start()
        self._ready.wait(timeout=45)
        if not self.available:
            log.warning(
                "could not launch headless Chromium -- run: "
                "playwright install chromium -- XSS execution "
                "verification disabled until then")
            return False

        log.info("headless Chromium ready (1/%d browser workers) -- XSS "
                 "findings will be execution-verified before being marked "
                 "confirmed", self.pool_size)
        for i in range(1, self.pool_size):
            wt = threading.Thread(target=self._worker_loop,
                                  name=f"xsscan-verifier-{i}", daemon=True)
            self._worker_threads.append(wt)
            wt.start()
        return True

    def stop(self) -> None:
        for _ in self._worker_threads:
            self._work_queue.put(None)
        for t in self._worker_threads:
            if t.is_alive():
                t.join(timeout=5)

    def _worker_loop(self) -> None:
        """Runs entirely on its own dedicated thread: owns its own
        sync_playwright() + browser for their whole lifetime, and drains
        work items put on the shared queue by verify_* calls from any
        thread. Each pool worker does this independently -- that's what
        lets `pool_size` verifications run at once instead of queueing
        behind a single browser."""
        browser = None
        try:
            pw = sync_playwright().start()
            browser = pw.chromium.launch(headless=True)
            self._local.pw = pw
            self._local.browser = browser
            with self._launch_lock:
                self._launched_ok += 1
                self.available = True
        except Exception as e:
            log.debug("chromium launch failed on a verifier worker: %s", e)
        finally:
            self._ready.set()   # only unblocks start() the first time; harmless after

        if browser is None:
            return

        while True:
            item = self._work_queue.get()
            if item is None:
                break
            fn, result_box, done_event = item
            try:
                result_box.append(fn())
            except Exception as e:                     # never let one bad probe kill a worker
                result_box.append(e)
            finally:
                done_event.set()

        try:
            self._local.browser.close()
            self._local.pw.stop()
        except Exception:
            pass

    def _dispatch(self, fn: Callable):
        """Run `fn` (a zero-arg callable that touches Playwright objects)
        on whichever pool worker picks it up next, and block the calling
        thread until it finishes. Safe to call concurrently from multiple
        threads -- the queue fans work out across all pool workers, each
        with its own browser, instead of serializing everything through
        just one."""
        result_box: list = []
        done_event = threading.Event()
        self._work_queue.put((fn, result_box, done_event))
        done_event.wait()
        result = result_box[0] if result_box else None
        if isinstance(result, Exception):
            raise result
        return result

    # ------------------------------------------------------------------ #
    # Public verification calls -- safe to call from any thread
    # ------------------------------------------------------------------ #
    def verify_get(self, url: str, cookies: dict, headers: dict,
                   marker: Optional[str] = None) -> VerificationResult:
        """Navigate to `url` (a real browser GET) and check whether a
        JavaScript dialog fires. If `marker` is given, only a dialog whose
        message contains it counts; otherwise any dialog counts."""
        if not self.available:
            return VerificationResult(verified=False, checked=False,
                                      error="headless browser not available")

        def nav(page):
            page.goto(url, timeout=self.timeout * 1000, wait_until="load")

        return self._dispatch(lambda: self._run(nav, cookies, headers, marker, url))

    def verify_post(self, url: str, data: dict, cookies: dict, headers: dict,
                    marker: Optional[str] = None) -> VerificationResult:
        """Submit `data` as a real POST form navigation to `url` (so the
        response is parsed and executed like a normal page load, not an
        XHR whose body is inert) and check whether a dialog fires."""
        if not self.available:
            return VerificationResult(verified=False, checked=False,
                                      error="headless browser not available")

        inputs = "".join(
            f'<input type="hidden" name="{_esc_attr(k)}" value="{_esc_attr(v)}">'
            for k, v in data.items())
        form_html = (
            f'<html><body><form id="xf" method="POST" action="{_esc_attr(url)}">'
            f'{inputs}</form>'
            f'<script>document.getElementById("xf").submit();</script>'
            f'</body></html>'
        )

        def nav(page):
            page.set_content(form_html, timeout=self.timeout * 1000)
            page.wait_for_load_state("load", timeout=self.timeout * 1000)

        return self._dispatch(lambda: self._run(nav, cookies, headers, marker, url))

    def verify_stored(self, url: str, cookies: dict, headers: dict,
                      marker: str) -> VerificationResult:
        """Revisit a page believed to render a previously-submitted stored
        payload, and check whether the dialog carrying `marker` fires.
        Marker matching is required here (unlike verify_get) because a
        stored page can carry more than one probe at once."""
        return self.verify_get(url, cookies, headers, marker=marker)

    def verify_custom(self, navigate: Callable, cookies: dict, headers: dict,
                      marker: Optional[str], origin_url: str) -> VerificationResult:
        """Run an arbitrary navigation/interaction sequence -- e.g. setting
        location.hash after the initial load to trigger a hashchange
        listener, or clicking a javascript: anchor -- and check whether a
        matching dialog fires. `navigate` receives a Playwright `page` and
        must run entirely synchronously; it is itself dispatched onto the
        worker thread, so it's safe for it to call any Playwright method.
        Used by the DOM-XSS prober for sinks a single page.goto() can't
        trigger on its own."""
        if not self.available:
            return VerificationResult(verified=False, checked=False,
                                      error="headless browser not available")
        return self._dispatch(lambda: self._run(navigate, cookies, headers, marker, origin_url))

    # ------------------------------------------------------------------ #
    # Runs only on the worker thread (called via _dispatch)
    # ------------------------------------------------------------------ #
    def _run(self, navigate: Callable, cookies: dict, headers: dict,
             marker: Optional[str], origin_url: str) -> VerificationResult:
        fired = {"ok": False, "text": ""}
        context = None
        try:
            context = self._local.browser.new_context(ignore_https_errors=True)
            if headers:
                try:
                    context.set_extra_http_headers(headers)
                except Exception:
                    pass
            if cookies:
                try:
                    context.add_cookies(_playwright_cookies(cookies, origin_url))
                except Exception:
                    pass

            def on_dialog(dialog):
                fired["ok"] = True
                fired["text"] = dialog.message
                try:
                    dialog.dismiss()
                except Exception:
                    pass

            page = context.new_page()
            page.on("dialog", on_dialog)
            try:
                navigate(page)
            except PWTimeoutError:
                pass    # a slow/hanging page is fine -- we still check for a dialog below
            except Exception as e:
                return VerificationResult(verified=False, checked=True,
                                          error=f"navigation error: {e}")

            page.wait_for_timeout(int(self.settle_wait * 1000))

            if fired["ok"] and (marker is None or marker in fired["text"]):
                return VerificationResult(
                    verified=True, checked=True,
                    evidence=f"JavaScript dialog fired: {fired['text']!r}")
            if fired["ok"]:
                return VerificationResult(
                    verified=False, checked=True,
                    evidence=f"a dialog fired but didn't carry the expected "
                             f"marker (got {fired['text']!r}) -- likely unrelated")
            return VerificationResult(
                verified=False, checked=True,
                evidence="no JavaScript dialog fired -- payload did not execute")
        except Exception as e:
            return VerificationResult(verified=False, checked=True, error=str(e))
        finally:
            try:
                if context:
                    context.close()
            except Exception:
                pass


def _esc_attr(s) -> str:
    return (str(s).replace("&", "&amp;").replace('"', "&quot;")
            .replace("<", "&lt;").replace(">", "&gt;"))


def _playwright_cookies(cookies: dict, url: str) -> list:
    host = urllib.parse.urlsplit(url).hostname or ""
    return [{"name": k, "value": v, "domain": host, "path": "/"}
            for k, v in cookies.items()]
