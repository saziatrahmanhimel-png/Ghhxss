"""Crawler: automatic discovery of URLs, parameters, and forms.

Performs a breadth-first walk of the target starting from a seed URL,
staying within the configured scope (same host or same path prefix).

Every page is parsed for:
  * <a href>, <area>, <link>, <script src>, <img src>, <iframe>,
    <frame>, <embed>, <source>, and <meta http-equiv=refresh>
  * <form> elements (GET and POST) with all field types
  * query-string parameters on every discovered URL

Output is a list of InjectionPoint objects that the scanner later fuzzes.

v1 is static-HTML only -- no JavaScript execution. If you need JS-driven
discovery later, swap the fetch layer for a headless browser (Playwright)
and keep the same InjectionPoint contract.
"""
from __future__ import annotations

import logging
import re
import threading
import time
import urllib.parse
from collections import deque
from dataclasses import dataclass, field
from typing import Callable, Optional

import requests
from bs4 import BeautifulSoup

log = logging.getLogger("xsscan.crawler")

# Heuristic: params that look like CSRF/state tokens are kept constant
# during fuzzing so requests still succeed (e.g. Django CSRF, ASP.NET
# __VIEWSTATE). They are carried in requests but never injected into.
TOKEN_RE = re.compile(
    r"(csrf|xsrf|token|nonce|authenticity|viewstate|eventvalidation|session|_sid)", re.I
)

# Input types that carry user-controlled data and are worth fuzzing.
FUZZABLE_TYPES = {
    "text", "search", "url", "email", "tel", "password", "number",
    "date", "datetime-local", "time", "hidden", "textarea", "select",
}
NON_FUZZABLE_TYPES = {"submit", "button", "image", "file", "reset"}


@dataclass
class InjectionPoint:
    """One injectable location: URL + method + full parameter map.

    `params` holds every parameter needed to make a valid request
    (including tokens). `param_names` is the subset the scanner should
    fuzz. `response` is the baseline response captured during crawling,
    used by the analyzer to tell real reflections from page noise.
    """
    url: str
    method: str                                     # GET | POST
    params: dict                                    # name -> value
    param_names: list                               # fuzzable subset
    source: str                                     # seed|link|form
    response: Optional[requests.Response] = None    # baseline
    extra: dict = field(default_factory=dict)

    def __repr__(self) -> str:
        return f"<InjectionPoint {self.method} {self.url} fuzz={self.param_names}>"


class Crawler:
    def __init__(self, session: requests.Session, *, scope: str = "host",
                 max_depth: int = 3, max_pages: int = 100, delay: float = 0.0,
                 timeout: int = 10, verify_ssl: bool = True,
                 respect_robots: bool = False,
                 on_point: Optional[Callable[["InjectionPoint"], None]] = None,
                 pause_event: Optional[threading.Event] = None,
                 stop_event: Optional[threading.Event] = None):
        self.session = session
        self.scope = scope            # "host" | "prefix" | "all"
        self.max_depth = max_depth
        self.max_pages = max_pages
        self.delay = delay
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self.respect_robots = respect_robots
        self.on_point = on_point

        # pause_event: cleared = paused (workers block); set = running.
        # stop_event: set = stop as soon as possible (graceful, no partial
        # requests are aborted mid-flight -- the crawl loop just exits early).
        self.pause_event = pause_event or threading.Event()
        if pause_event is None:
            self.pause_event.set()
        self.stop_event = stop_event or threading.Event()

        self.points: list[InjectionPoint] = []
        self.seen: set[str] = set()
        self._point_keys: set[tuple] = set()
        self.seed_host: str = ""
        self.seed_prefix: str = ""
        self._last_request = 0.0
        self._disallowed: list[str] = []
        self.stopped = False

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def discover(self, seed_url: str) -> list[InjectionPoint]:
        """Crawl from `seed_url` and return every injection point found."""
        seed = self._normalize(seed_url)
        sp = urllib.parse.urlsplit(seed)
        self.seed_host = sp.netloc
        self.seed_prefix = f"{sp.scheme}://{sp.netloc}{sp.path.rstrip('/')}"

        if self.respect_robots:
            self._load_robots()

        # Seed itself may carry fuzzable query parameters
        if sp.query:
            self._add_point(seed, "GET", self._parse_query(sp.query),
                            source="seed")

        queue: deque[tuple[str, int]] = deque([(seed, 0)])
        while queue and len(self.seen) < self.max_pages:
            if self.stop_event.is_set():
                self.stopped = True
                log.info("crawl stopped early: %d pages, %d points so far",
                         len(self.seen), len(self.points))
                break
            self.pause_event.wait()   # blocks here while paused
            if self.stop_event.is_set():
                self.stopped = True
                break

            url, depth = queue.popleft()
            if self._visited(url) or not self._in_scope(url):
                continue
            self._mark_visited(url)
            log.debug("crawl [d=%d] %s", depth, url)

            try:
                resp = self._fetch(url)
            except requests.RequestException as e:
                log.debug("fetch failed %s: %s", url, e)
                continue

            if resp.status_code >= 400 or not self._looks_like_html(resp):
                continue
            if not self._in_scope(resp.url):
                continue  # redirected off-target: don't mine it

            soup = BeautifulSoup(resp.text, "html.parser")

            # --- forms first (most valuable: real input surfaces) ---
            for form in self._extract_forms(soup, resp.url):
                self._point_from_form(form, resp)
                # POST endpoints can still expose links via GET
                queue.append((form["action"], depth + 1))

            # --- links / assets ---
            for link in self._extract_links(soup, resp.url):
                lp = urllib.parse.urlsplit(link)
                if lp.query:
                    # URL carries parameters -> fuzzable GET point
                    clean = urllib.parse.urlunsplit(
                        (lp.scheme, lp.netloc, lp.path, "", lp.fragment))
                    self._add_point(clean, "GET",
                                    self._parse_query(lp.query),
                                    source="link", response=resp)
                if depth + 1 <= self.max_depth and self._in_scope(link):
                    queue.append((link, depth + 1))

            log.info("crawled %s (forms=%d links=%d, total points=%d)",
                     resp.url, len(soup.find_all("form")),
                     len(self._extract_links(soup, resp.url)), len(self.points))

        log.info("crawl complete: %d pages, %d injection points",
                 len(self.seen), len(self.points))
        return self.points

    def crawl(self, seed_url: str) -> list[InjectionPoint]:
        """Alias for discover()."""
        return self.discover(seed_url)

    # ------------------------------------------------------------------ #
    # Pause / resume / stop controls (shared events also passed to Scanner
    # so one pair of controls governs the whole crawl+scan pipeline)
    # ------------------------------------------------------------------ #
    def pause(self) -> None:
        self.pause_event.clear()

    def resume(self) -> None:
        self.pause_event.set()

    def stop(self) -> None:
        self.stop_event.set()
        self.pause_event.set()   # unblock anything currently paused so it can exit

    # ------------------------------------------------------------------ #
    # Point construction
    # ------------------------------------------------------------------ #
    def _add_point(self, url: str, method: str, params: dict,
                   source: str, response: Optional[requests.Response] = None,
                   fuzzable: Optional[list] = None) -> None:
        if fuzzable is None:
            fuzzable = [n for n in params
                        if n and not TOKEN_RE.search(n)]
        else:
            fuzzable = [n for n in fuzzable if n in params]
        if not fuzzable:
            return

        clean_url = urllib.parse.urldefrag(url).url
        key = (method, clean_url, tuple(sorted(params.items())))
        if key in self._point_keys:
            return
        self._point_keys.add(key)
        point = InjectionPoint(
            url=clean_url, method=method, params=dict(params),
            param_names=fuzzable, source=source, response=response,
        )
        self.points.append(point)
        log.debug("point: %s %s params=%s fuzz=%s",
                  method, clean_url, list(params), fuzzable)
        if self.on_point:
            try:
                self.on_point(point)
            except Exception as e:
                log.debug("on_point callback failed: %s", e)

    def _point_from_form(self, form: dict,
                         resp: requests.Response) -> None:
        params: dict = {}
        # action URLs can carry query params; merge them in
        params.update(self._parse_query(
            urllib.parse.urlsplit(form["action"]).query))
        fuzzable: list = []
        for inp in form["inputs"]:
            name, value, itype = inp["name"], inp["value"], inp["type"]
            params[name] = value
            if (itype in FUZZABLE_TYPES and name not in params or
                    itype in FUZZABLE_TYPES and not TOKEN_RE.search(name)):
                # keep only non-token, fuzzable names
                fuzzable.append(name)
        self._add_point(form["action"], form["method"], params,
                        source="form", response=resp,
                        fuzzable=[n for n in dict.fromkeys(fuzzable)
                                  if not TOKEN_RE.search(n)])

    # ------------------------------------------------------------------ #
    # Extraction helpers
    # ------------------------------------------------------------------ #
    def _extract_links(self, soup: BeautifulSoup, page_url: str) -> set:
        base_tag = soup.find("base", href=True)
        base = (urllib.parse.urljoin(page_url, base_tag["href"])
                if base_tag else page_url)

        raw: set[str] = set()
        for sel in ("a[href]", "area[href]"):
            for tag in soup.select(sel):
                href = (tag.get("href") or "").strip()
                if href:
                    raw.add(urllib.parse.urljoin(base, href))

        for sel in ("script[src]", "img[src]", "iframe[src]",
                    "frame[src]", "embed[src]", "source[src]", "link[href]"):
            for tag in soup.select(sel):
                src = tag.get("src") or tag.get("href")
                if src:
                    raw.add(urllib.parse.urljoin(base, src))

        for meta in soup.select("meta[http-equiv]"):
            if meta.get("http-equiv", "").lower() == "refresh":
                m = re.search(r"url\s*=\s*(.+)", meta.get("content", ""), re.I)
                if m:
                    raw.add(urllib.parse.urljoin(
                        base, m.group(1).strip().strip("'\"")))

        out: set[str] = set()
        for link in raw:
            p = urllib.parse.urlsplit(link)
            if p.scheme in ("http", "https") and p.netloc:
                out.add(urllib.parse.urldefrag(link).url)
        return out

    def _extract_forms(self, soup: BeautifulSoup, page_url: str) -> list[dict]:
        forms = []
        for form in soup.find_all("form"):
            action = form.get("action") or page_url
            action = urllib.parse.urljoin(page_url, action)
            method = (form.get("method") or "GET").upper()
            if method not in ("GET", "POST"):
                method = "GET"

            inputs = []
            for inp in form.find_all("input"):
                name = inp.get("name")
                if not name:
                    continue
                itype = (inp.get("type") or "text").lower()
                if itype == "file":
                    continue  # multipart uploads: out of v1 scope
                value = inp.get("value", "")
                if itype in ("checkbox", "radio") and not value:
                    value = "on"
                inputs.append({"name": name, "value": value, "type": itype})

            for ta in form.find_all("textarea"):
                if ta.get("name"):
                    inputs.append({"name": ta["name"],
                                   "value": ta.get_text(), "type": "textarea"})

            for sel in form.find_all("select"):
                if not sel.get("name"):
                    continue
                chosen = None
                for opt in sel.find_all("option"):
                    if opt.has_attr("selected"):
                        chosen = opt.get("value")
                        break
                if chosen is None:
                    first = sel.find("option")
                    chosen = first.get("value", "") if first else ""
                inputs.append({"name": sel["name"], "value": chosen,
                               "type": "select"})

            for btn in form.find_all("button"):
                if btn.get("name"):
                    inputs.append({"name": btn["name"],
                                   "value": btn.get("value", ""),
                                   "type": "button"})

            forms.append({"action": action, "method": method,
                          "inputs": inputs})
        return forms

    @staticmethod
    def _parse_query(query: str) -> dict:
        return dict(urllib.parse.parse_qsl(query, keep_blank_values=True))

    # ------------------------------------------------------------------ #
    # Fetch / scope / robots
    # ------------------------------------------------------------------ #
    def _fetch(self, url: str) -> requests.Response:
        self._throttle()
        resp = self.session.get(url, timeout=self.timeout,
                                verify=self.verify_ssl,
                                allow_redirects=True)
        self._last_request = time.monotonic()
        return resp

    def _throttle(self) -> None:
        if self.delay <= 0:
            return
        elapsed = time.monotonic() - self._last_request
        if elapsed < self.delay:
            time.sleep(self.delay - elapsed)

    def _load_robots(self) -> None:
        try:
            r = self.session.get(
                f"{self.seed_prefix.split('//')[0]}//{self.seed_host}/robots.txt"
                if False else f"http{'s' if 'https' in self.seed_prefix else ''}"
                f"://{self.seed_host}/robots.txt",
                timeout=self.timeout, verify=self.verify_ssl)
        except requests.RequestException:
            return
        if r.status_code != 200:
            return
        for line in r.text.splitlines():
            line = line.strip()
            if line.lower().startswith("disallow:"):
                path = line.split(":", 1)[1].strip()
                if path:
                    self._disallowed.append(path)

    def _robots_blocked(self, url: str) -> bool:
        if not self._disallowed:
            return False
        path = urllib.parse.urlsplit(url).path
        return any(path.startswith(d) for d in self._disallowed)

    def _in_scope(self, url: str) -> bool:
        sp = urllib.parse.urlsplit(url)
        if sp.scheme not in ("http", "https"):
            return False
        if self.respect_robots and self._robots_blocked(url):
            return False
        if self.scope == "all":
            return True
        if self.scope == "prefix":
            return (sp.netloc == self.seed_host and
                    sp.path.startswith(self.seed_prefix))
        return sp.netloc == self.seed_host  # default: same host

    @staticmethod
    def _normalize(url: str) -> str:
        url = url.strip()
        if not url.startswith(("http://", "https://")):
            url = "http://" + url
        return urllib.parse.urldefrag(url).url

    def _visited(self, url: str) -> bool:
        return url in self.seen

    def _mark_visited(self, url: str) -> None:
        self.seen.add(url)

    @staticmethod
    def _looks_like_html(resp: requests.Response) -> bool:
        ctype = resp.headers.get("Content-Type", "").lower()
        if "html" in ctype:
            return True
        if ctype and not ctype.startswith("text/"):
            return False
        head = resp.text.lstrip()[:128].lower()
        return head.startswith(("<html", "<!doctype html", "<!doctype"))
