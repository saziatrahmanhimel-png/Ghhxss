"""Scanner: the injection engine.

Takes InjectionPoints from the crawler and fires one request per
(payload variant, parameter) pair, keeping every other parameter at its
baseline value so any reflection can be attributed to exactly one
parameter -- the classic one-at-a-time injection discipline.

Each request is delivered to the analyzer (duck-typed) together with a
RequestContext describing what was injected, where, and in which
encoding. The scanner never inspects response bodies itself; analysis
is entirely the analyzer's job (Step 4).

Features:
  * one-parameter-at-a-time injection for exact attribution
  * raw + encoded payload variants per (point, param)
  * GET (query string) and POST (urlencoded body) support
  * bounded thread pool with a shared rate limiter
  * retries with linear backoff on transient network errors
  * progress callback for CLI reporting
  * analyzer exceptions are caught so analysis bugs can't abort a scan

Out of v1 scope: JSON/GraphQL request bodies, multipart uploads,
DOM-based detection (needs a browser), and auth-aware crawling.
"""
from __future__ import annotations

import logging
import threading
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable, Optional

if TYPE_CHECKING:
    from .analyzer import Finding

import requests

from . import payloads as P
from .crawler import InjectionPoint

log = logging.getLogger("xsscan.scanner")

ProgressCallback = Callable[[int, int], None]   # (completed, total)


# ---------------------------------------------------------------------- #
# Data contracts
# ---------------------------------------------------------------------- #
@dataclass
class RequestContext:
    """Everything the analyzer needs to judge one injected request."""
    point: InjectionPoint
    param: str                   # the fuzzable parameter that carried the payload
    payload: str                 # exact string the application received
    variant: str                 # raw | url | url2 | entity | unicode
    category: str                # payload category from payloads.PAYLOADS
    description: str
    request_url: str = ""        # actual wire URL (filled after send)
    sent_at: float = 0.0


@dataclass
class RequestOutcome:
    """Result of one request: response + metadata for the analyzer."""
    context: RequestContext
    status: int
    response: Optional[requests.Response]     # None on hard failure
    error: Optional[str] = None
    retries: int = 0
    elapsed: float = 0.0

    @property
    def ok(self) -> bool:
        return self.response is not None


@dataclass
class ScanResult:
    """Aggregated outcome of a full scan run."""
    target: str
    started: float = 0.0
    finished: float = 0.0
    requests_sent: int = 0
    requests_failed: int = 0
    requests_skipped: int = 0        # jobs that never went out (user stopped)
    retries: int = 0
    stopped_early: bool = False
    findings: list = field(default_factory=list)     # analyzer Finding objects
    outcomes: list = field(default_factory=list)     # every RequestOutcome
    errors: list = field(default_factory=list)       # (url, param, payload, error)

    @property
    def duration(self) -> float:
        return self.finished - self.started

    @property
    def reflected_count(self) -> int:
        return sum(1 for f in self.findings if getattr(f, "reflected", False))


# ---------------------------------------------------------------------- #
# Scanner
# ---------------------------------------------------------------------- #
class Scanner:
    def __init__(self, session: requests.Session, analyzer, *,
                 concurrency: int = 4, delay: float = 0.1,
                 timeout: int = 10, retries: int = 1,
                 verify_ssl: bool = True, max_requests: int = 0,
                 on_progress: Optional[ProgressCallback] = None,
                 on_finding: Optional[Callable[["Finding"], None]] = None,
                 pause_event: Optional[threading.Event] = None,
                 stop_event: Optional[threading.Event] = None):
        self.session = session
        self.analyzer = analyzer
        self.concurrency = max(1, concurrency)
        self.delay = delay
        self.timeout = timeout
        self.retries = retries
        self.verify_ssl = verify_ssl
        self.max_requests = max_requests or None
        self.on_progress = on_progress
        self.on_finding = on_finding

        # Shared with the Crawler when both are driven from the same job,
        # so one Pause/Resume/Stop control governs the whole pipeline.
        # pause_event cleared = paused (workers block before each request).
        # stop_event set = stop ASAP; in-flight requests finish, queued
        # jobs return immediately without being sent.
        self.pause_event = pause_event or threading.Event()
        if pause_event is None:
            self.pause_event.set()
        self.stop_event = stop_event or threading.Event()
        self.stopped = False

        self._throttle_lock = threading.Lock()
        self._last_request = 0.0

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def scan(self, points: list[InjectionPoint]) -> ScanResult:
        """Run the full injection pass over all points."""
        result = ScanResult(target=points[0].url if points else "?")
        result.started = time.time()

        jobs = self._build_jobs(points)
        if self.max_requests:
            jobs = jobs[: self.max_requests]
        total = len(jobs)
        log.info("scanning %d jobs across %d point(s)", total, len(points))
        if total == 0:
            result.finished = time.time()
            return result

        if self.concurrency == 1 or total <= 1:
            for i, job in enumerate(jobs, 1):
                outcome = self._execute(job)
                result.outcomes.append(outcome)
                self._accumulate(result, outcome)
                self._report_progress(i, total)
        else:
            with ThreadPoolExecutor(max_workers=self.concurrency,
                                    thread_name_prefix="xsscan") as pool:
                futures = {pool.submit(self._execute, j): j for j in jobs}
                done = 0
                for fut in as_completed(futures):
                    result.outcomes.append(fut.result())
                    self._accumulate(result, result.outcomes[-1])
                    done += 1
                    self._report_progress(done, total)

        result.findings.sort(
            key=lambda f: (getattr(f, "exploitable", False),
                           getattr(f, "confidence", 0.0)),
            reverse=True)
        result.finished = time.time()
        log.info("scan done: %d requests, %d reflected, %d errors",
                 result.requests_sent, result.reflected_count,
                 len(result.errors))
        return result

    # ------------------------------------------------------------------ #
    # Job expansion
    # ------------------------------------------------------------------ #
    def _build_jobs(self, points):
        """Expand points into (point, param, payload, variant, category, desc)."""
        jobs = []
        for point in points:
            for param in point.param_names:
                for payload, category, desc in P.PAYLOADS:
                    jobs.append((point, param, payload, "raw",
                                 category, desc))
                    for label, variant in P.encoded_variants(payload):
                        jobs.append((point, param, variant, label,
                                     category, desc))
        return jobs

    # ------------------------------------------------------------------ #
    # Per-request execution
    # ------------------------------------------------------------------ #
    def _execute(self, job) -> RequestOutcome:
        point, param, payload, variant, category, desc = job
        url, kwargs = self._build_request(point, param, payload, variant)
        context = RequestContext(point=point, param=param, payload=payload,
                                 variant=variant, category=category,
                                 description=desc, request_url=url,
                                 sent_at=time.time())

        # Block here while paused; bail out immediately (no request sent)
        # once a stop has been requested.
        self.pause_event.wait()
        if self.stop_event.is_set():
            self.stopped = True
            return RequestOutcome(context=context, status=0, response=None,
                                  error="stopped by user", retries=0,
                                  elapsed=0.0)

        start = time.monotonic()
        attempt = 0
        while True:
            self._throttle()
            try:
                resp = self.session.request(
                    point.method, url, **kwargs,
                    timeout=self.timeout, verify=self.verify_ssl,
                    allow_redirects=True)
                context.request_url = resp.request.url or url
                log.debug("ok %s %s param=%s variant=%s [%d] %.2fs",
                          point.method, url, param, variant,
                          resp.status_code, time.monotonic() - start)
                return RequestOutcome(context=context,
                                      status=resp.status_code, response=resp,
                                      retries=attempt,
                                      elapsed=time.monotonic() - start)
            except requests.RequestException as e:
                attempt += 1
                if attempt <= self.retries:
                    time.sleep(0.5 * attempt)   # linear backoff
                    continue
                log.debug("fail %s %s param=%s variant=%s: %s",
                          point.method, url, param, variant, e)
                return RequestOutcome(context=context, status=0,
                                      response=None, error=str(e),
                                      retries=attempt - 1,
                                      elapsed=time.monotonic() - start)

    def _build_request(self, point: InjectionPoint, param: str,
                       payload: str, variant: str):
        """Return (url, kwargs) for one injection.

        Raw variants go through requests' own encoder (dict -> urlencode),
        which percent-encodes and lets the server decode back to the exact
        payload string.

        Pre-encoded variants ("url", "url2", "entity", "unicode") must be
        sent *literally* -- if we passed them through params=/data=, requests
        would double-encode the '%' and '&' characters and the test would be
        meaningless. So we build the wire string ourselves and percent-encode
        the value exactly once, which the server's single decode then
        restores to the intended encoded string.
        """
        params = dict(point.params)
        params[param] = payload

        base = self._clean_url(point.url)

        if variant == "raw":
            if point.method == "POST":
                return base, dict(data=params)
            return base, dict(params=params)

        # --- literal variant: hand-craft the wire encoding ---
        others = {k: v for k, v in params.items() if k != param}
        wire = urllib.parse.urlencode(others, doseq=True)
        pair = (urllib.parse.quote(param, safe="") + "=" +
                urllib.parse.quote(payload, safe=""))
        wire = f"{wire}&{pair}" if wire else pair

        if point.method == "POST":
            return base, dict(data=wire, headers={
                "Content-Type": "application/x-www-form-urlencoded"})
        sep = "&" if urllib.parse.urlsplit(base).query else "?"
        return base + sep + wire, {}

    @staticmethod
    def _clean_url(url: str) -> str:
        """Strip query/fragment so all params come from the params dict.

        Form actions may carry a query string that the crawler already
        merged into point.params; keeping it in the URL would send those
        parameters twice.
        """
        parts = urllib.parse.urlsplit(url)
        return urllib.parse.urlunsplit(
            (parts.scheme, parts.netloc, parts.path, "", ""))

    # ------------------------------------------------------------------ #
    # Pause / resume / stop controls
    # ------------------------------------------------------------------ #
    def pause(self) -> None:
        self.pause_event.clear()

    def resume(self) -> None:
        self.pause_event.set()

    def stop(self) -> None:
        self.stop_event.set()
        self.pause_event.set()   # unblock anything currently paused so it can exit

    # ------------------------------------------------------------------ #
    # Plumbing
    # ------------------------------------------------------------------ #
    def _throttle(self) -> None:
        if self.delay <= 0:
            return
        with self._throttle_lock:
            elapsed = time.monotonic() - self._last_request
            if elapsed < self.delay:
                time.sleep(self.delay - elapsed)
            self._last_request = time.monotonic()

    def _accumulate(self, result: ScanResult, outcome: RequestOutcome) -> None:
        if outcome.error == "stopped by user":
            result.requests_skipped += 1
            result.stopped_early = True
            return
        result.requests_sent += 1
        if not outcome.ok:
            result.requests_failed += 1
            result.retries += outcome.retries
            result.errors.append((outcome.context.point.url,
                                  outcome.context.param,
                                  outcome.context.payload, outcome.error))
            return
        try:
            finding = self.analyzer.analyze(outcome.context, outcome.response)
            if finding is not None:
                result.findings.append(finding)
                if self.on_finding:
                    try:
                        self.on_finding(finding)
                    except Exception as e:
                        log.debug("on_finding callback failed: %s", e)
        except Exception as e:   # an analyzer bug must never abort the scan
            log.warning("analyzer error on %s %s param=%s: %s",
                        outcome.context.point.method,
                        outcome.context.point.url,
                        outcome.context.param, e)

    def _report_progress(self, done: int, total: int) -> None:
        if self.on_progress:
            try:
                self.on_progress(done, total)
            except Exception:
                pass


# ---------------------------------------------------------------------- #
# Placeholder analyzer so the scanner is testable before Step 4
# ---------------------------------------------------------------------- #
class PassthroughAnalyzer:
    """Temporary stub -- replaced by the real Analyzer in Step 4."""

    def analyze(self, context: RequestContext,
                response: requests.Response):
        return None
