"""DOM-based XSS prober.

Reflected/stored testing (analyzer.py, stored.py) both depend on the
payload showing up in something the *server* sent back. That can never
catch a DOM XSS: a client-side sink (document.write, .innerHTML, a
jQuery selector, an anchor's href, an AngularJS expression, ...) reads
location.search / location.hash directly in the browser and the server
never sees the payload at all, so nothing is ever reflected for the
Analyzer to notice.

So this module skips server-side detection entirely and drives the
Verifier directly. For every page the crawler visited it navigates a
real headless browser to that page with a DOM-XSS payload placed in:

  (a) every query parameter the page is known to accept
  (b) the URL fragment, present on the initial page load
  (c) the URL fragment set *after* the page has already loaded, to
      trigger a `hashchange` listener (e.g. a jQuery-selector-on-
      hashchange sink, which never re-reads a hash that was already
      there on load)
  (d) a javascript: URI placed in a parameter that ends up as an
      anchor's href, then clicking that anchor (a plain page load can't
      trigger this sink -- it only fires on click)

It also tries a short list of public, well-documented AngularJS sandbox-
escape expressions (see https://portswigger.net/research/
dom-based-angularjs-sandbox-escapes) in case the page runs user input
through AngularJS's expression evaluator.

Exactly like reflected/stored verification, the only thing that ever
counts as a finding here is the payload's own alert() actually firing,
observed the same way (a real JS dialog, matched by a unique per-probe
marker) -- "the browser didn't error out" or "the payload appears in the
DOM" is not evidence of anything.

Known limits (stated plainly rather than silently missed): this only
tests what a page does on load / on a hash change of a URL the crawler
already found. It won't trigger a sink that only fires after a button
click unrelated to a javascript: href, behind an XHR/fetch call the
crawler never made, or gated by application state (login, multi-step
forms) the crawler didn't reach.
"""
from __future__ import annotations

import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Callable, Optional
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

from .verifier import Verifier, marker_id

log = logging.getLogger("xsscan.domxss")

MAX_PAGES = 60            # cap how many discovered pages get DOM-probed
MAX_PARAMS_PER_PAGE = 6   # cap query params tried per page
DEFAULT_CONCURRENCY = 4   # pages probed at once -- each probe's verify_*
                          # calls land on the Verifier's browser-worker
                          # pool, so this should roughly track pool_size
GENERIC_PARAM_GUESSES = ["search", "returnPath", "returnUrl", "redirect",
                         "next", "url", "message", "q"]


def _js_payloads(token: str) -> list[tuple[str, str]]:
    """(payload, technique) -- generic DOM-sink payloads, placed as a
    query param value or URL fragment. Every payload's own execution
    proof is alert('<token>')."""
    a = f"alert('{token}')"
    return [
        (f"<img src=x onerror={a}>", "innerHTML / document.write sink"),
        (f"<svg onload={a}>", "innerHTML / document.write sink (SVG)"),
        (f"\"><img src=x onerror={a}>", "document.write attribute breakout"),
        (f"</select><img src=x onerror={a}>", "document.write inside a raw-text element"),
    ]


def _angular_payloads(token: str) -> list[tuple[str, str]]:
    """Known AngularJS sandbox-escape expressions -- public research, see
    module docstring. Only fires if the page actually evaluates user
    input as an AngularJS expression."""
    a = f"alert('{token}')"
    return [
        (f"{{{{constructor.constructor('{a}')()}}}}", "AngularJS sandbox escape (constructor)"),
        (f"{{{{$eval.constructor('{a}')()}}}}", "AngularJS sandbox escape ($eval)"),
        (f"{{{{$on.constructor('{a}')()}}}}", "AngularJS sandbox escape ($on)"),
    ]


@dataclass
class DomFinding:
    url: str
    technique: str
    payload: str
    injection_point: str          # e.g. "param=search", "fragment (on load)", "fragment (hashchange event)"
    verified: bool
    checked: bool
    evidence: str


class DomXSSTester:
    def __init__(self, verifier: Verifier, *, cookies: dict, headers: dict,
                 concurrency: int = DEFAULT_CONCURRENCY,
                 on_event: Optional[Callable[[str], None]] = None,
                 on_progress: Optional[Callable[[], None]] = None,
                 should_stop: Optional[Callable[[], bool]] = None):
        self.verifier = verifier
        self.cookies = cookies
        self.headers = headers
        self.concurrency = max(1, concurrency)
        self.on_event = on_event
        self.on_progress = on_progress
        self.should_stop = should_stop or (lambda: False)

    def _emit(self, msg: str) -> None:
        if self.on_event:
            try:
                self.on_event(msg)
            except Exception:
                pass

    def test_pages(self, page_urls: list[str],
                   param_names_by_url: dict[str, list[str]]) -> list[DomFinding]:
        """`page_urls`: every page the crawler visited (with or without
        query params). `param_names_by_url`: known fuzzable param names
        per URL, from the crawler's InjectionPoints, used to target
        query-based sinks precisely instead of only guessing.

        Each page is probed independently, so pages run concurrently
        (bounded by `concurrency`) instead of one at a time -- every probe's
        actual browser work still funnels through the Verifier's own
        worker pool, which is what actually bounds how much runs at once."""
        if not self.verifier.available:
            self._emit("DOM XSS probing skipped -- no headless browser available")
            return []
        urls = page_urls[:MAX_PAGES]
        if not urls:
            return []

        out: list[DomFinding] = []
        out_lock = threading.Lock()

        def _run_one(url: str) -> None:
            if self.should_stop():
                return
            findings = self._probe_page(url, param_names_by_url.get(url, []))
            with out_lock:
                out.extend(findings)
            if self.on_progress:
                try:
                    self.on_progress()
                except Exception:
                    pass

        if self.concurrency == 1 or len(urls) == 1:
            for url in urls:
                _run_one(url)
        else:
            with ThreadPoolExecutor(max_workers=self.concurrency) as pool:
                list(pool.map(_run_one, urls))
        return out

    def _probe_page(self, url: str, param_names: list[str]) -> list[DomFinding]:
        results: list[DomFinding] = []
        parts = urlsplit(url)
        base_params = list(dict(parse_qsl(parts.query, keep_blank_values=True)))
        candidate_params = list(dict.fromkeys(
            param_names + base_params + GENERIC_PARAM_GUESSES))[:MAX_PARAMS_PER_PAGE]

        # (a) query-param sinks (generic + AngularJS)
        for pname in candidate_params:
            if self.should_stop():
                return results
            for payload, technique in _js_payloads(marker_id()) + _angular_payloads(marker_id()):
                token = _extract_token(payload)
                probe_url = _with_param(url, pname, payload)
                self._emit(f"DOM probe: {technique} via ?{pname}= on {url}")
                vr = self.verifier.verify_get(probe_url, self.cookies, self.headers, marker=token)
                if vr.verified:
                    results.append(DomFinding(
                        url=url, technique=technique, payload=payload,
                        injection_point=f"param={pname}", verified=True,
                        checked=True, evidence=vr.evidence))
                    return results   # page confirmed vulnerable -- move on

        # (b) fragment present on initial load
        for payload, technique in _js_payloads(marker_id()):
            if self.should_stop():
                return results
            token = _extract_token(payload)
            probe_url = _with_fragment(url, payload)
            self._emit(f"DOM probe: {technique} via URL fragment (on load) on {url}")
            vr = self.verifier.verify_get(probe_url, self.cookies, self.headers, marker=token)
            if vr.verified:
                results.append(DomFinding(
                    url=url, technique=technique, payload=payload,
                    injection_point="fragment (on load)", verified=True,
                    checked=True, evidence=vr.evidence))
                return results

        # (c) fragment set *after* load, to trigger a hashchange listener
        for payload, technique in _js_payloads(marker_id()):
            if self.should_stop():
                return results
            token = _extract_token(payload)
            self._emit(f"DOM probe: {technique} via hashchange event on {url}")
            vr = self._verify_hashchange(url, payload, token)
            if vr.verified:
                results.append(DomFinding(
                    url=url, technique=technique, payload=payload,
                    injection_point="fragment (hashchange event)", verified=True,
                    checked=True, evidence=vr.evidence))
                return results

        # (d) javascript: URI written into an anchor href, then clicked
        token = marker_id()
        payload = f"javascript:alert('{token}')"
        for pname in candidate_params[:3]:
            if self.should_stop():
                return results
            probe_url = _with_param(url, pname, payload)
            self._emit(f"DOM probe: anchor href javascript: URI via ?{pname}= on {url}")
            vr = self._verify_click_js_href(probe_url, token)
            if vr.verified:
                results.append(DomFinding(
                    url=url, technique="anchor href javascript: URI sink",
                    payload=payload, injection_point=f"param={pname} (clicked)",
                    verified=True, checked=True, evidence=vr.evidence))
                return results

        return results

    # -------------------------- multi-step navigations -------------------------- #
    def _verify_hashchange(self, url: str, payload: str, token: str):
        base = url.split("#")[0]
        timeout_ms = self.verifier.timeout * 1000

        def nav(page):
            page.goto(base, timeout=timeout_ms, wait_until="load")
            page.evaluate("(h) => { location.hash = h; }", payload)
            page.wait_for_timeout(300)

        return self.verifier.verify_custom(nav, self.cookies, self.headers, token, base)

    def _verify_click_js_href(self, url: str, token: str):
        timeout_ms = self.verifier.timeout * 1000

        def nav(page):
            page.goto(url, timeout=timeout_ms, wait_until="load")
            try:
                link = page.locator("a[href^='javascript:']").first
                if link.count() > 0:
                    link.click(timeout=2000)
            except Exception:
                pass   # no such anchor on this page -- not this sink

        return self.verifier.verify_custom(nav, self.cookies, self.headers, token, url)


# ---------------------------------------------------------------------- #
def _extract_token(payload: str) -> str:
    i = payload.find("XSSPROBE-")
    if i == -1:
        return ""
    j = payload.find("'", i)
    return payload[i:j] if j != -1 else payload[i:i + 19]


def _with_param(url: str, name: str, value: str) -> str:
    parts = urlsplit(url)
    q = dict(parse_qsl(parts.query, keep_blank_values=True))
    q[name] = value
    return urlunsplit((parts.scheme, parts.netloc, parts.path,
                       urlencode(q), parts.fragment))


def _with_fragment(url: str, value: str) -> str:
    parts = urlsplit(url)
    return urlunsplit((parts.scheme, parts.netloc, parts.path,
                       parts.query, value))
