"""Reporter: aggregation and report generation.

Turns a ScanResult (raw outcomes + findings) into a structured ScanReport
and serializes it as JSON and as a self-contained HTML document.

Aggregation responsibilities:
  * roll findings up per (URL, method, parameter)
  * dedupe identical findings so the same payload echoed by several
    encoding variants isn't reported N times
  * count unique vulnerable endpoints (exploitable vs reflected-only)
  * surface scan metadata: duration, request counts, transport errors,
    per-parameter coverage

Output formats:
  * JSON  -- machine-readable, CI-friendly
  * HTML  -- single self-contained file, inline CSS, no external assets,
             safe to email or archive
  * text  -- console summary for the CLI

Security note: payloads and evidence snippets are attacker-controlled
strings. When embedding them in the HTML report they MUST be escaped;
the report itself is a possible meta-XSS vector. We escape with
html.escape(quote=True) everywhere user data touches the document.
"""
from __future__ import annotations

import html as html_mod
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from .analyzer import Finding
from .scanner import ScanResult

log = logging.getLogger("xsscan.reporter")

SEVERITY_HIGH = "High"
SEVERITY_MEDIUM = "Medium"
SEVERITY_LOW = "Low"


def severity_of(f: Finding) -> str:
    """Raw, unencoded reflection of an executable payload -> High."""
    if f.exploitable and f.matched_as == "raw":
        return SEVERITY_HIGH
    if f.exploitable:
        return SEVERITY_MEDIUM
    return SEVERITY_LOW


def status_of(f: Finding) -> str:
    """Where a finding sits on the reflected -> confirmed spectrum.

    'exploitable'/severity above are the static heuristic (context +
    payload shape) -- useful for prioritizing what to check, but never
    proof by themselves. 'confirmed' is only ever set by the browser
    verification stage actually observing the payload execute. Only
    'confirmed' should ever be reported to a user as "XSS confirmed".
    """
    if f.confirmed:
        return "confirmed"
    if f.exploitable:
        return "candidate"          # heuristically likely, not yet verified
    if f.reflected:
        return "reflected"          # present in the response, doesn't look executable
    return "not_confirmed"


def esc(s: Optional[str]) -> str:
    """Escape a user-controlled string for safe embedding in HTML."""
    return html_mod.escape(s or "", quote=True)


# ---------------------------------------------------------------------- #
# Aggregation
# ---------------------------------------------------------------------- #
@dataclass
class EndpointSummary:
    """Rollup of all findings for one (URL, method) pair."""
    url: str
    method: str
    params: list                      # fuzzable param names
    param_count: int
    findings: int
    exploitable: int
    max_severity: str
    contexts: list


def _dedupe(findings: list[Finding]) -> list[Finding]:
    """Keep the highest-confidence occurrence of each unique
    (url, method, param, payload) triple.

    The same payload can come back through several encoding variants
    (raw, url, entity...) on the same parameter; reporting all of them
    inflates the count without adding information.
    """
    best: dict[tuple, Finding] = {}
    for f in findings:
        key = (f.url, f.method, f.param, f.payload)
        prev = best.get(key)
        if prev is None or f.confidence > prev.confidence:
            best[key] = f
    return sorted(best.values(),
                  key=lambda f: (f.exploitable, f.confidence),
                  reverse=True)


@dataclass
class ScanReport:
    target: str
    started: float
    finished: float
    duration: float
    requests_sent: int
    requests_failed: int
    retries: int
    errors: list
    findings: list
    deduped: list
    endpoints: list
    stats: dict
    generated_at: str

    # ------------------------------------------------------------------ #
    @classmethod
    def from_result(cls, result: ScanResult) -> "ScanReport":
        findings = list(result.findings)
        deduped = _dedupe(findings)

        endpoints: dict[tuple, dict] = {}
        for f in deduped:
            key = (f.url, f.method)
            e = endpoints.setdefault(key, {
                "url": f.url, "method": f.method,
                "params": set(), "findings": 0, "exploitable": 0,
                "contexts": set(),
            })
            e["params"].add(f.param)
            e["findings"] += 1
            if f.exploitable:
                e["exploitable"] += 1
            e["contexts"].add(f.context)

        sev = {SEVERITY_HIGH: 0, SEVERITY_MEDIUM: 0, SEVERITY_LOW: 0}
        for f in deduped:
            sev[severity_of(f)] += 1

        endpoints_out = []
        for key in sorted(endpoints):
            e = endpoints[key]
            endpoints_out.append(EndpointSummary(
                url=e["url"], method=e["method"],
                params=sorted(e["params"]), param_count=len(e["params"]),
                findings=e["findings"], exploitable=e["exploitable"],
                max_severity=(SEVERITY_HIGH if e["exploitable"]
                              else SEVERITY_LOW),
                contexts=sorted(e["contexts"]),
            ))

        stats = {
            "requests_sent": result.requests_sent,
            "requests_failed": result.requests_failed,
            "requests_skipped": getattr(result, "requests_skipped", 0),
            "stopped_early": getattr(result, "stopped_early", False),
            "retries": result.retries,
            "errors": len(result.errors),
            "findings_total": len(findings),
            "findings_deduped": len(deduped),
            "exploitable": sum(1 for f in deduped if f.exploitable),
            "confirmed": sum(1 for f in deduped if f.confirmed),
            "severity": sev,
            "endpoints": len(endpoints_out),
            "parameters_tested": sum(len(e["params"]) for e in
                                     endpoints.values()),
        }

        return cls(
            target=result.target,
            started=result.started,
            finished=result.finished,
            duration=result.duration,
            requests_sent=result.requests_sent,
            requests_failed=result.requests_failed,
            retries=result.retries,
            errors=list(result.errors),
            findings=findings,
            deduped=deduped,
            endpoints=endpoints_out,
            stats=stats,
            generated_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        )

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_json(self, path: str) -> None:
        """Write a machine-readable JSON report."""
        data = {
            "generated_at": self.generated_at,
            "target": self.target,
            "duration_seconds": round(self.duration, 2),
            "stats": self.stats,
            "errors": [
                {"url": u, "param": p, "payload": pl, "error": err}
                for u, p, pl, err in self.errors
            ],
            "endpoints": [
                {
                    "url": e.url, "method": e.method, "params": e.params,
                    "findings": e.findings, "exploitable": e.exploitable,
                    "max_severity": e.max_severity, "contexts": e.contexts,
                }
                for e in self.endpoints
            ],
            "findings": [finding_to_dict(f) for f in self.deduped],
        }
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False)
        log.info("wrote JSON report: %s", path)

    def to_html(self, path: str) -> None:
        """Write a self-contained HTML report (inline CSS, no assets)."""
        rows = "\n".join(_finding_row(f) for f in self.deduped) or \
            "<tr><td colspan=9 class=muted>No reflections detected.</td></tr>"
        endpoints_html = "\n".join(_endpoint_row(e) for e in self.endpoints) or \
            "<tr><td colspan=4 class=muted>No endpoints tested.</td></tr>"
        errors_html = "\n".join(_error_row(e) for e in self.errors) or \
            "<tr><td colspan=4 class=muted>No transport errors.</td></tr>"

        s = self.stats
        doc = (
            _HTML_HEAD +
            f"""
<body>
<header>
  <h1>SRH_XSS_FINDER Report</h1>
  <p class=sub>Target: <code>{esc(self.target)}</code> &mdash;
     generated {esc(self.generated_at)}</p>
</header>

<section class=cards>
  <div class=card><b>{s['requests_sent']}</b><span>requests sent</span></div>
  <div class=card><b>{s['findings_deduped']}</b><span>reflections</span></div>
  <div class="card sev-hi"><b>{s['exploitable']}</b><span>exploitable</span></div>
  <div class="card sev-me"><b>{s['severity']['Medium']}</b><span>medium</span></div>
  <div class="card sev-lo"><b>{s['severity']['Low']}</b><span>low</span></div>
  <div class=card><b>{s['endpoints']}</b><span>endpoints</span></div>
  <div class=card><b>{s['parameters_tested']}</b><span>params tested</span></div>
  <div class=card><b>{self.duration:.1f}s</b><span>duration</span></div>
  <div class="card err"><b>{s['errors']}</b><span>transport errors</span></div>
</section>

{_FILTER_BAR}

<section>
  <h2>Findings ({len(self.deduped)})</h2>
  <table>
    <thead><tr><th>Status</th><th>Severity</th><th>Method</th><th>URL</th><th>Parameter</th>
      <th>Context</th><th>Matched as</th><th>Confidence</th><th>Payload</th></tr></thead>
    <tbody>
{rows}
    </tbody>
  </table>
</section>

<section>
  <h2>Endpoint summary</h2>
  <table>
    <thead><tr><th>Method</th><th>URL</th><th>Params</th>
      <th>Findings</th><th>Exploitable</th></tr></thead>
    <tbody>
{endpoints_html}
    </tbody>
  </table>
</section>

<section>
  <h2>Transport errors ({len(self.errors)})</h2>
  <table>
    <thead><tr><th>Method</th><th>URL</th><th>Param</th><th>Error</th></tr></thead>
    <tbody>
{errors_html}
    </tbody>
  </table>
</section>

<footer>Generated by SRH_XSS_FINDER &mdash; authorized security testing only.</footer>
{_REPORT_SCRIPT}
</body></html>
"""
        )
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(doc)
        log.info("wrote HTML report: %s", path)

    def to_text(self) -> str:
        """Console-friendly summary."""
        s = self.stats
        lines = [
            f"SRH_XSS_FINDER — {self.target}",
            f"  {s['requests_sent']} requests, {s['requests_failed']} failed, "
            f"{self.duration:.1f}s",
            f"  {s['findings_deduped']} reflections, "
            f"{s['exploitable']} candidate ({s.get('confirmed', 0)} confirmed by "
            f"browser execution) "
            f"(High={s['severity']['High']}, Med={s['severity']['Medium']}, "
            f"Low={s['severity']['Low']})",
            f"  {s['endpoints']} endpoints, {s['parameters_tested']} params tested",
            "",
        ]

        confirmed = [f for f in self.deduped if f.confirmed]
        others = [f for f in self.deduped if not f.confirmed]

        for f in confirmed:
            lines += [
                "━" * 30,
                "XSS CONFIRMED",
                "━" * 30,
                f"Type:               Reflected",
                f"URL:                {f.url}",
                f"Parameter / Field:  {f.param}",
                f"HTTP Method:        {f.method}",
                f"Successful Payload: {f.payload}",
                f"Execution Evidence: {f.execution_evidence}",
                f"Confidence:         Confirmed",
                "",
            ]
        for f in others:
            status = status_of(f)
            label = {"candidate": "Reflected, not yet execution-verified",
                     "reflected": "Reflected but not exploitable",
                     "not_confirmed": "Not confirmed"}[status]
            lines.append(
                f"[{label}] {severity_of(f):6} conf={f.confidence:.2f} {f.method} "
                f"{f.url} ?{f.param} [{f.context_label}] as={f.matched_as} "
                f"payload={f.payload!r}"
            )
        if self.errors:
            lines.append("")
            lines.append(f"Transport errors: {len(self.errors)} "
                         "(see JSON/HTML report for details)")
        return "\n".join(lines)


def finding_to_dict(f: Finding) -> dict:
    return {
        "url": f.url,
        "method": f.method,
        "param": f.param,
        "payload": f.payload,
        "variant": f.variant,
        "category": f.category,
        "description": f.description,
        "reflected": f.reflected,
        "exploitable": f.exploitable,
        "confidence": f.confidence,
        "context": f.context,
        "context_label": f.context_label,
        "matched_as": f.matched_as,
        "offset": f.offset,
        "length": f.length,
        "snippet": f.snippet,
        "occurrences": f.occurrences,
        "status": f.status,
        "response_url": f.response_url,
        "baseline_present": f.baseline_present,
        "notes": f.notes,
        "security_headers": dict(f.security_headers),
        "severity": severity_of(f),
        "confirmed": f.confirmed,
        "execution_evidence": f.execution_evidence,
        "status_label": status_of(f),
    }


# ---------------------------------------------------------------------- #
# HTML row builders
# ---------------------------------------------------------------------- #
def _finding_row(f: Finding) -> str:
    payload = esc(f.payload)
    sev = severity_of(f)
    status = status_of(f)
    status_label = {"confirmed": "XSS CONFIRMED", "candidate": "Candidate (unverified)",
                    "reflected": "Reflected, not exploitable",
                    "not_confirmed": "Not confirmed"}[status]
    return f"""
    <tr class="finding-row sev-{sev.lower()} status-{status}">
      <td><span class="badge status-badge-{status}">{status_label}</span></td>
      <td><span class=badge>{sev}</span></td>
      <td>{f.method}</td>
      <td class=mono>{_copy_cell(f.url, f.url, "URL")}</td>
      <td class=mono>{esc(f.param)}</td>
      <td>{esc(f.context_label)}</td>
      <td>{esc(f.matched_as)}</td>
      <td>{f.confidence:.2f}</td>
      <td class=mono>{_copy_cell(f.payload, f.payload, "payload")}</td>
    </tr>
    <tr class="detail sev-{sev.lower()}">
      <td colspan=9>
        <div class=detail-inner>
          <p class=mono>payload: {payload} {_copy_btn("payload", f.payload)}</p>
          <p>verification URL: {_copy_cell(f.response_url or f.url, f.response_url or f.url, "URL")}</p>
          <p>snippet: {snippet_html(f.snippet)}</p>
          <p>context: {esc(f.context_label)} ({esc(f.context)}) &mdash;
             matched as <code>{esc(f.matched_as)}</code> at offset {f.offset}
             ({f.length} chars), status {f.status}</p>
          <p>response URL: <code>{esc(f.response_url)}</code></p>
          <p>occurrences: {', '.join(f"{s}@{a}" for s, a, b in f.occurrences) or 'n/a'}</p>
          <ul class=notes>{''.join(f'<li>{esc(n)}</li>' for n in f.notes)}</ul>
          <p class=muted>security headers:
             {', '.join(f'<code>{esc(k)}</code>' for k in f.security_headers) or 'none observed'}</p>
          <p><b>Execution verification:</b>
             {esc(f.execution_evidence) if f.execution_evidence else
             ('not run' if status == 'candidate' else 'n/a')}</p>
        </div>
      </td>
    </tr>"""


def snippet_html(snippet: str) -> str:
    """Render an evidence snippet with the reflected span highlighted.

    The snippet format is `{before}<<<{payload}>>>{after}`; split on the
    markers, escape the three parts independently, and wrap the payload
    in a <mark> so the reflection is visible at a glance.
    """
    before, _, rest = snippet.partition("<<<")
    payload, _, after = rest.partition(">>>")
    return (f'<code class=snip>{esc(before)}'
            f'<mark class=hit>{esc(payload)}</mark>'
            f'{esc(after)}</code>')


def _endpoint_row(e: EndpointSummary) -> str:
    return (f'<tr><td>{e.method}</td><td class=mono>{esc(e.url)}</td>'
            f'<td>{", ".join(esc(p) for p in e.params)}</td>'
            f'<td>{e.findings}</td>'
            f'<td><span class="badge sev-{e.max_severity.lower()}">'
            f'{e.exploitable}</span></td></tr>')


def _error_row(err) -> str:
    url, param, payload, message = err
    return (f'<tr><td class=mono>{esc(url)}</td>'
            f'<td class=mono>{esc(param)}</td>'
            f'<td class=mono>{esc(payload)}</td>'
            f'<td class=muted>{esc(message)}</td></tr>')


# ---------------------------------------------------------------------- #
# HTML shell
# ---------------------------------------------------------------------- #
_HTML_HEAD = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SRH_XSS_FINDER Report</title>
<style>
:root{--bg:#0f1420;--panel:#171e2e;--line:#26314a;--fg:#dbe4f4;
      --mut:#8fa3c2;--hi:#ff5d5d;--me:#ffb454;--lo:#6faeff;--ok:#3ddc97;}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);
  font:14px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;}
header{padding:28px 32px;border-bottom:1px solid var(--line);
  background:linear-gradient(180deg,#1a2440,#171e2e);}
h1{margin:0;font-size:22px;letter-spacing:.5px}
h2{font-size:15px;margin:0 0 12px;text-transform:uppercase;letter-spacing:1px;
  color:var(--mut)}
.sub{color:var(--mut);margin:6px 0 0}
section{padding:24px 32px;border-bottom:1px solid var(--line)}
.cards{display:flex;flex-wrap:wrap;gap:12px;padding:24px 32px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:8px;
  padding:14px 18px;min-width:120px}
.card b{display:block;font-size:22px}
.card span{color:var(--mut);font-size:12px}
.sev-hi b{color:var(--hi)}.sev-me b{color:var(--me)}.sev-lo b{color:var(--lo)}
.err b{color:var(--hi)}
table{width:100%;border-collapse:collapse}
th{text-align:left;color:var(--mut);font-size:12px;text-transform:uppercase;
  letter-spacing:.5px;border-bottom:1px solid var(--line);padding:8px}
td{padding:8px;border-bottom:1px solid var(--line);vertical-align:top;
  word-break:break-word}
.badge{padding:2px 8px;border-radius:20px;font-size:12px;font-weight:700}
.sev-high .badge{background:#3d1b22;color:var(--hi)}
.status-badge-confirmed{background:#12321f;color:var(--ok);border:1px solid #3ddc9750}
.status-badge-candidate{background:#3d2f1b;color:var(--me)}
.status-badge-reflected,.status-badge-not_confirmed{background:#1b2333;color:var(--mut)}
tr.status-confirmed{border-left:3px solid var(--ok)}
.sev-medium .badge{background:#3d2f1b;color:var(--me)}
.sev-low .badge{background:#1b2a3d;color:var(--lo)}
tr.detail td{background:#131a29;padding:0}
.detail-inner{padding:14px 16px;border-left:3px solid var(--line)}
.sev-high .detail-inner{border-left-color:var(--hi)}
.sev-medium .detail-inner{border-left-color:var(--me)}
.sev-low .detail-inner{border-left-color:var(--lo)}
.mono{font-family:inherit}
code{background:#0b101c;border:1px solid var(--line);border-radius:4px;
  padding:1px 5px;font-size:12.5px}
code.snip{display:block;padding:8px 10px;white-space:pre-wrap;
  overflow-wrap:anywhere}
mark.hit{background:#4a1a1a;color:#ff8f8f;border-radius:3px;padding:1px 2px}
ul.notes{margin:6px 0 0;padding-left:18px;color:var(--mut)}
.muted{color:var(--mut)}
footer{padding:20px 32px;color:var(--mut);font-size:12px}
.copy-btn{background:#1b2333;border:1px solid var(--line);color:var(--mut);
  border-radius:5px;padding:3px 9px;font-size:11px;cursor:pointer;
  font-family:inherit;white-space:nowrap;margin:2px 4px 2px 0;}
.copy-btn:hover{border-color:#5b9dff;color:var(--fg)}
.copy-btn.copied{border-color:var(--ok);color:var(--ok)}
.cell-copy{display:flex;align-items:flex-start;gap:6px;flex-wrap:wrap}
.cell-copy .txt{flex:1;min-width:0;overflow-wrap:anywhere}
.filter-bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;
  padding:14px 32px;border-bottom:1px solid var(--line);background:#131a29;
  position:sticky;top:0;z-index:2;}
.filter-bar .lbl{color:var(--mut);font-size:12px;margin-right:4px}
.filter-bar .sev-bar,.filter-bar .status-bar{display:flex;gap:8px;flex-wrap:wrap}
.filter-bar button{background:var(--panel);border:1px solid var(--line);color:var(--fg);
  border-radius:20px;padding:5px 14px;font-size:12px;cursor:pointer;font-family:inherit;}
.filter-bar button:hover{border-color:#5b9dff}
.filter-bar button.on{background:#5b9dff;border-color:#5b9dff;color:#0b101c;font-weight:700}
.filter-bar button.on.f-high{background:var(--hi);border-color:var(--hi)}
.filter-bar button.on.f-medium{background:var(--me);border-color:var(--me)}
.filter-bar button.on.f-low{background:var(--lo);border-color:var(--lo)}
.filter-bar button.on.f-confirmed{background:var(--ok);border-color:var(--ok);color:#0b101c}
.filter-bar button.on.f-candidate{background:var(--me);border-color:var(--me)}
.filter-bar button.on.f-reflected,.filter-bar button.on.f-not_confirmed{background:#3a4459;border-color:#3a4459}
.filter-hidden{display:none !important}
</style></head>
"""

_REPORT_SCRIPT = """
<script>
function copyText(btn){
  var val = btn.getAttribute('data-copy') || '';
  function done(){
    var orig = btn.getAttribute('data-label') || btn.textContent;
    btn.textContent = 'Copied \\u2713';
    btn.classList.add('copied');
    setTimeout(function(){ btn.textContent = orig; btn.classList.remove('copied'); }, 1400);
  }
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(val).then(done, function(){ fallbackCopy(val, done); });
  } else {
    fallbackCopy(val, done);
  }
}
function fallbackCopy(val, done){
  var ta = document.createElement('textarea');
  ta.value = val; ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.focus(); ta.select();
  try { document.execCommand('copy'); } catch(e) {}
  document.body.removeChild(ta);
  done();
}
var _reportFilters = { sev: 'all', status: 'all' };
function filterSeverity(sev, btn){
  document.querySelectorAll('.sev-bar button').forEach(function(b){ b.classList.remove('on'); });
  btn.classList.add('on');
  _reportFilters.sev = sev;
  _applyReportFilters();
}
function filterStatus(status, btn){
  document.querySelectorAll('.status-bar button').forEach(function(b){ b.classList.remove('on'); });
  btn.classList.add('on');
  _reportFilters.status = status;
  _applyReportFilters();
}
function _applyReportFilters(){
  document.querySelectorAll('.finding-row').forEach(function(tr){
    var sevOk = (_reportFilters.sev === 'all') || tr.classList.contains('sev-' + _reportFilters.sev);
    var statusOk = (_reportFilters.status === 'all') || tr.classList.contains('status-' + _reportFilters.status);
    var match = sevOk && statusOk;
    tr.classList.toggle('filter-hidden', !match);
    var next = tr.nextElementSibling;
    if(next && next.classList.contains('detail')){
      next.classList.toggle('filter-hidden', !match);
    }
  });
}
</script>
"""

_FILTER_BAR = """
<div class="filter-bar">
  <span class="lbl">Severity:</span>
  <span class="sev-bar">
    <button class="on" onclick="filterSeverity('all',this)">All</button>
    <button class="f-high" onclick="filterSeverity('high',this)">High</button>
    <button class="f-medium" onclick="filterSeverity('medium',this)">Medium</button>
    <button class="f-low" onclick="filterSeverity('low',this)">Low</button>
  </span>
  <span class="lbl" style="margin-left:14px">Status:</span>
  <span class="status-bar">
    <button class="on" onclick="filterStatus('all',this)">All status</button>
    <button class="f-confirmed" onclick="filterStatus('confirmed',this)">Confirmed XSS</button>
    <button class="f-candidate" onclick="filterStatus('candidate',this)">Heuristic candidate</button>
    <button class="f-reflected" onclick="filterStatus('reflected',this)">Reflected only</button>
    <button class="f-not_confirmed" onclick="filterStatus('not_confirmed',this)">Not confirmed</button>
  </span>
</div>
"""


def _copy_btn(label: str, value: str) -> str:
    """A small button that copies `value` to the clipboard when clicked."""
    return (f'<button type="button" class="copy-btn" data-copy="{esc(value)}" '
            f'data-label="Copy {esc(label)}" onclick="copyText(this)">'
            f'Copy {esc(label)}</button>')


def _copy_cell(text: str, value: str, label: str) -> str:
    """Table cell showing truncated/wrapped text plus a copy button for it."""
    return (f'<div class="cell-copy"><span class="txt mono">{esc(text)}</span>'
            f'{_copy_btn(label, value)}</div>')


def scan_and_report(analyzer, points, *, scanner_kwargs=None, json_path=None,
                    html_path=None) -> ScanReport:
    """Convenience wrapper: run the scanner, build the report, write files."""
    from .scanner import Scanner
    scanner = Scanner(analyzer.session if hasattr(analyzer, "session") else None,
                      analyzer, **(scanner_kwargs or {}))
    result = scanner.scan(points)
    report = ScanReport.from_result(result)
    if json_path:
        report.to_json(json_path)
    if html_path:
        report.to_html(html_path)
    return report
