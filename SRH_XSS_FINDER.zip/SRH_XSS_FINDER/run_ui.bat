@echo off
REM xsscan console launcher for Windows
REM Creates a venv on first run, installs dependencies, then starts the UI.

cd /d "%~dp0"

if not exist "venv\Scripts\python.exe" (
    echo [*] First run: creating virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo Could not find "python" on PATH. Install Python 3.10+ from python.org
        echo and re-run this script.
        pause
        exit /b 1
    )
    echo [*] Installing dependencies...
    venv\Scripts\python.exe -m pip install --upgrade pip
    venv\Scripts\python.exe -m pip install -r requirements.txt

    echo [*] Installing headless Chromium for XSS execution verification...
    echo     (this is a one-time ~150MB download; scanning still works without
    echo      it, but findings will only be heuristic, never confirmed)
    venv\Scripts\python.exe -m playwright install chromium
    if errorlevel 1 (
        echo [!] Chromium install failed or was skipped -- xsscan will still run,
        echo     but findings will be labeled "unverified" instead of confirmed.
        echo     You can retry any time with:
        echo       venv\Scripts\python.exe -m playwright install chromium
    )
)

echo [*] Starting xsscan console at http://127.0.0.1:8765
venv\Scripts\python.exe server.py
pause
