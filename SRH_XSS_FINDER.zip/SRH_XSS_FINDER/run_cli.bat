@echo off
REM Run the original xsscan CLI (no UI). Example:
REM   run_cli.bat https://app.example.com/ --depth 2 --html report.html

cd /d "%~dp0"

if not exist "venv\Scripts\python.exe" (
    echo [*] First run: creating virtual environment...
    python -m venv venv
    venv\Scripts\python.exe -m pip install --upgrade pip
    venv\Scripts\python.exe -m pip install -r requirements.txt
)

venv\Scripts\python.exe main.py %*
