# xsscan — setup & usage (Windows)

xsscan is a reflected + stored + DOM-based XSS scanner for **authorized**
penetration testing. This package adds a local web dashboard on top of
the same engine, so you don't have to use the CLI.

Only scan systems you own or have explicit written authorization to test.

## The core rule: reflected/stored/DOM ≠ confirmed

A payload showing up in a response, being accepted, being stored, or
appearing anywhere in the DOM is **not** treated as a vulnerability.
xsscan only ever labels something **"XSS CONFIRMED"** after replaying
the exact request in a real headless browser (Chromium, via Playwright)
and observing the payload's own `alert()` call actually fire — a genuine
JavaScript dialog, not a text match. Everything else is shown as a
clearly separate status: **candidate** (looks exploitable heuristically,
not yet execution-tested), **pending** (currently being checked in the
browser), **not executed** (loaded in a real browser, nothing fired), or
**reflected** (present in the response, doesn't look exploitable at
all). The same standard applies to stored XSS (submitting a payload and
finding it echoed back on another page is "located," not "confirmed") and
to DOM-based XSS (see below).

### What this covers now

- **Reflected XSS** — every discovered GET/POST parameter, fuzzed and
  execution-verified.
- **Stored XSS** — forms with name/email/comment/message-type fields:
  submit → revisit every crawled page → verify execution on whichever
  page renders it back.
- **DOM-based XSS** — payloads never reach the server here, so there's a
  dedicated module (`xsscan/domxss.py`) that drives the headless browser
  directly against every crawled page: each known query parameter, the
  URL fragment on load, the fragment set *after* load (to trigger a
  `hashchange` listener), and a `javascript:` URI written into a link
  and then clicked. It also tries a handful of public, well-documented
  AngularJS sandbox-escape expressions. This covers `document.write`,
  `.innerHTML`, jQuery selector/href sinks, and AngularJS expression
  sinks driven by `location.search`/`location.hash` — **not** sinks
  behind a button click unrelated to a link, an XHR/fetch call the
  crawler never triggered, or multi-step/logged-in application state the
  crawler didn't reach.

### What's intentionally out of scope

- **Exploit chains that steal another user's session** (cookie theft,
  password capture, CSRF-defense bypass via XSS) aren't automated here.
  Confirming a payload executes is a safe, non-destructive proof of
  concept; standing up a listener that exfiltrates a *different* user's
  credentials is real attacker infrastructure, and that's true even
  inside a training lab. If you're working through exercises that need
  this, it's worth doing that specific step by hand.
- **CSP bypass analysis and strict-CSP dangling-markup exfiltration**
  aren't automated. Confirmation here is "did `alert()` fire" — a CSP
  that blocks inline scripts will correctly make xsscan report
  "not executed," which is accurate, but working out a bypass for a
  *specific* target's policy, or exfiltrating data via a dangling markup
  injection (which doesn't call `alert()` at all), needs manual
  analysis.
- Filter-evasion payloads cover common, well-documented bypass patterns,
  not an exhaustive set — some heavily-customized WAF/filter combos may
  need a manually crafted payload xsscan doesn't ship with.

## Folder contents

```
xsscan/            the scan engine
  crawler.py, scanner.py, analyzer.py   discovery + injection + heuristic scoring
  reporter.py                           JSON/HTML/text report generation
  verifier.py                           headless-Chromium execution verification
  stored.py                             stored-XSS submit -> revisit -> verify
static/index.html  the dashboard UI
server.py          local web server that runs scans and serves the UI
main.py            original CLI entry point (still works standalone)
requirements.txt   Python dependencies
run_ui.bat          <- double-click this to launch the dashboard
run_cli.bat         <- run the original CLI instead
```

## 1. Install Python (one-time)

You need Python 3.10+. If you don't have it:

1. Go to https://www.python.org/downloads/
2. Download the latest Python 3.x installer for Windows.
3. Run it, and **check "Add python.exe to PATH"** on the first screen.
4. Finish the install.

Confirm it worked — open **Command Prompt** and run:
```
python --version
```

## 2. Launch the dashboard

1. Unzip this folder anywhere, e.g. `C:\Tools\xsscan`.
2. Double-click **`run_ui.bat`**.
   - First run: it creates a `venv` folder, installs Python dependencies
     (requests, beautifulsoup4, fastapi, uvicorn, playwright) — then
     downloads headless Chromium (~150MB, one time, needs internet). This
     step can take a couple of minutes on the first run only.
   - It then starts the server and opens `http://127.0.0.1:8765` in your
     browser automatically.
3. Leave the black console window open while you use the UI — it's the
   server. Closing it stops the app.

If the Chromium download fails or is skipped (offline install, corporate
proxy, etc.), the scanner still runs fine — it just can't confirm
anything, and every finding stays labeled "unverified" instead of
confirmed or rejected. You can retry any time with:
```
venv\Scripts\python.exe -m playwright install chromium
```

If Windows blocks the `.bat` file (SmartScreen), click **More info → Run
anyway** — it's a plain text batch script, you can open it in Notepad to
verify it only runs `python` locally, nothing else.

## 3. Using the dashboard

- **New scan** → enter the target URL → check the authorization box (the
  scan sends live payloads to every endpoint it finds, so this is a
  required confirmation, not a formality) → **Start scan**.
- Advanced options (collapsed by default): crawl depth/scope, concurrency,
  timeout, retries, cookies (for authenticated scanning), extra headers,
  user agent, TLS verification, minimum confidence, and a toggle for
  stored-XSS testing.

### While the scan is running

The scan moves through phases: **crawling** → **scanning** (reflected
injection) → **verifying** (replaying heuristic candidates in headless
Chromium) → **stored testing** (submitting to forms, revisiting pages,
verifying execution) → **DOM testing** (probing every crawled page's
query params, URL fragment, hashchange, and `javascript:` links directly
in the browser, since DOM XSS never touches the server) → **done**.

- **Pause / Resume / Stop** act directly on the crawler and scanner
  threads. Pause blocks before the next request goes out (in-flight
  requests still complete); Stop ends the scan and still produces a full
  report of whatever was found and verified up to that point. DOM/stored
  testing check the same stop signal between probes.
- Everything streams live over Server-Sent Events:
  - A **confirmed-XSS banner** at the top fills in the instant something
    is actually verified — reflected, stored, *or* DOM-based — with the
    exact URL, parameter/field/injection point, payload, and the
    execution evidence (e.g. `alert() fired: 'xss-probe'`). This is the
    direct answer to "which parameter is vulnerable and which payload
    worked" — and it only ever shows things that were proven, never
    heuristic guesses.
  - The **findings table** fills in live and is filterable by status:
    Confirmed / Verifying / Heuristic candidate / Not executed. Every row
    shows the payload, context, and (once checked) the exact execution
    evidence or why it *didn't* fire.
  - A separate **Stored XSS** panel and **DOM-based XSS** panel list
    their own results as they come in.
  - **Discovered endpoints** and a live **activity feed** fill in during
    the crawl, stored-testing, and DOM-testing phases.
  - Reloading the page mid-scan reconnects and catches you up.

### Once it finishes (or is stopped)

- Stat cards including a dedicated **Confirmed XSS** count, separate from
  heuristic candidates.
- **Download JSON** / **Download HTML report** — written only after
  verification and stored-XSS testing complete, so the downloaded report
  matches exactly what the dashboard showed, including execution evidence
  and a Stored XSS section. Every finding in the report distinguishes
  status: confirmed / candidate (unverified) / reflected / not confirmed
  — never just "found."

Past scans stay listed in the left sidebar for the life of the server
process (in-memory; they're cleared when you close the console window,
but the JSON/HTML files already written to `reports/` stay on disk).

## 4. Using the CLI instead (optional)

The original CLI still works unchanged:
```
run_cli.bat https://app.example.com/ --depth 2 --html report.html --json report.json
```
Run `run_cli.bat --help` for all flags. Note: the CLI does not run the
headless-browser verification or stored-XSS stages (those are UI-only for
now) — its findings are the same heuristic candidates as before. Use the
dashboard when you need execution-confirmed results.

## Notes on how the UI is wired

`server.py` builds a `requests.Session` from your form inputs, runs
`Crawler.discover()` then `Scanner.scan()` in a background thread, and
hands the result to `ScanReport.from_result()`.

- `Crawler`/`Scanner` gained `on_point`/`on_finding` callbacks and shared
  `pause_event`/`stop_event` so the dashboard can stream progress and
  pause/resume/stop the pipeline (both optional and exception-safe — the
  CLI is unaffected).
- Every heuristic-exploitable candidate with a raw (unencoded) payload is
  queued to a single dedicated headless-Chromium worker thread
  (`xsscan/verifier.py`) that replays the exact request and watches for a
  real JavaScript dialog. The result is written back onto the actual
  `Finding` object (not just the UI's copy), so the exported report — not
  only the live dashboard — reflects confirmed vs. candidate status.
- After the reflected scan, `xsscan/stored.py` submits a uniquely-marked
  payload into every field of every discovered form, then searches all
  crawled pages (plus the submission response) for that marker. Finding
  the marker only proves it was *stored* — the page is then re-loaded in
  the same headless browser, and only a matching dialog counts as
  confirmed.
